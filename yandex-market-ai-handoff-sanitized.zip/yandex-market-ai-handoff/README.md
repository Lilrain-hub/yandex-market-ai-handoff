# Yandex Market 商家知识库 · AI 接入研究交接

这是公开脱敏的前端源码副本，供 IT 同事研究如何接入真实大模型与知识检索（RAG）。保留当前首页、导航、阅读页、搜索、文章 ID 和知识数据结构。**目前没有连接模型，也没有聊天后端；首页 AI 按钮显示“筹备中”。**

## 本地运行

建议 Node.js 22 或 24、pnpm 11：

```sh
pnpm install --frozen-lockfile
pnpm dev
```

打开终端输出的本地地址。其他命令：

```sh
pnpm test              # 导航、搜索、配图占位、语料一致性与 Markdown 安全检查
pnpm check:public      # 公开副本的文件允许清单和常见敏感信息检查
pnpm export:knowledge  # 重新导出 data/knowledge-corpus.json
pnpm build             # 生产静态资源位于 dist/client/
```

本仓库没有生产部署配置，不会自动替换现有网站。源码直接放在根目录，GitHub “Code → Download ZIP” 或 git clone 均可获取完整项目。

## IT 从哪里开始

1. 阅读 [AI 接入研究说明](docs/AI-INTEGRATION.md)，了解当前入口、数据、前后端边界和待确认问题。
2. 查看 [结构化脱敏语料](data/knowledge-corpus.json)：46 个非重定向文章记录，含标题、Markdown、块结构、稳定 ID、相关文章 ID 与相对来源路径。
3. 运行页面，检查 `src/HeroConsultation.jsx` 的输入与提交逻辑，以及 `src/StudioHome.jsx` 的首页挂载位置。
4. 查看 `src/knowledge-data.js` / `src/knowledge-utils.js`，区分现有关键词搜索与未来后端 RAG。

## 脱敏与数据限制

原始文档、真实后台截图、联系二维码、内部部署标识、Git 历史、个人路径和环境文件均未包含。后台图片位置替换为清晰标记的占位图，商业/财务参数改为研究示例。详见 [脱敏范围](docs/REDACTION.md)。

**这些样例不能作为真实经营、费率或回款政策依据，也不能直接当作生产 RAG 知识库。** 生产资料应由技术团队通过受控渠道导入，并经过授权、脱敏和业务复核。

当前代码来源为既有 React + Vite 项目，未为交接改换技术栈。第三方与品牌权利说明见 [NOTICE](NOTICE.md)。
