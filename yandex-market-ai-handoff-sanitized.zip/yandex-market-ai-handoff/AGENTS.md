# Public research handoff

This is a sanitized frontend research copy. Read README.md and docs/REDACTION.md first. Preserve navigation, article IDs and existing routes when studying AI integration. The AI entry currently shows a preparation notice; do not describe it as connected to a model.

Production model calls, keys, retrieval, authorization and retention belong on a separately designed backend. Never import private documents, real account screenshots, contact QR codes, environment files or production credentials into this public repository. Keep fixture knowledge clearly marked and do not use it as current merchant policy.

Run pnpm test, pnpm check:public and pnpm build after relevant changes. Third-party notices must remain with their assets.
