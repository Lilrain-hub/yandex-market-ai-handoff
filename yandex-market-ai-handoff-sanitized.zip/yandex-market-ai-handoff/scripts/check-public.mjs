import { readdir, readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const failures = [], files = [];
const approvedAssets = JSON.parse(await readFile(new URL('../docs/public-assets.json', import.meta.url), 'utf8'));
const rootFiles = new Set(['README.md','NOTICE.md','AGENTS.md','.gitignore','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','index.html','vite.config.mjs']);
async function walk(folder, prefix='') {
  for (const item of await readdir(folder, { withFileTypes: true })) {
    if (['.git','node_modules','dist'].includes(item.name) && !prefix) continue;
    const rel = prefix + item.name;
    if (item.isSymbolicLink()) { failures.push(`${rel}: unexpected symlink`); continue; }
    if (item.isDirectory()) await walk(path.join(folder,item.name), rel + '/');
    else files.push(rel);
  }
}
await walk(root);
const patterns = [
  ['private document URL', /https?:\/\/[^\s\x22\x27<>]*docs\.qq\.com[^\s\x22\x27<>]*/i],
  ['personal path', /\/Users\/[a-zA-Z0-9._-]+\//],
  ['deployment identity', /appgprj_[a-z0-9]{20,}/i],
  ['token value', /(?:github_pat_[A-Za-z0-9_]{20,}|ghp_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{24,})/],
  ['private key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ['email value', /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i],
  ['CN mobile number', /(?<!\d)1[3-9]\d{9}(?!\d)/],
  ['identity number', /(?<!\d)\d{17}[\dXx](?!\d)/],
];
for (const rel of files) {
  const allowed = rootFiles.has(rel) || /^src\/[^/]+\.(jsx?|css)$/.test(rel) || /^scripts\/(export-knowledge|check-public)\.mjs$/.test(rel)
    || /^tests\/handoff\.test\.mjs$/.test(rel) || /^docs\/(AI-INTEGRATION|REDACTION|public-assets)\.(md|json)$/.test(rel)
    || rel === 'data/knowledge-corpus.json' || approvedAssets.includes(rel);
  if (!allowed) failures.push(`${rel}: outside export allowlist`);
  if (rel.startsWith('public/') && !/\.(svg|txt)$/.test(rel)) continue;
  const text = await readFile(path.join(root,rel), 'utf8');
  if (rel === 'scripts/check-public.mjs') continue;
  for (const [label,pattern] of patterns) if (pattern.test(text)) failures.push(`${rel}: ${label}`);
}
for (const asset of approvedAssets) {
  try { await stat(path.join(root, asset)); } catch { failures.push(`${asset}: missing asset`); }
}
if (failures.length) { console.error(failures.join('\n')); process.exitCode = 1; }
else console.log(`PASS: ${files.length} allowlisted files; no forbidden text patterns or original guide screenshots.`);
