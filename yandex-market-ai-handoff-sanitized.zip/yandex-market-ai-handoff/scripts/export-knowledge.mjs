import { mkdir, writeFile } from 'node:fs/promises';
import { articles, categories, chapters } from '../src/knowledge-data.js';
const corpus = {
  schemaVersion: 1, dataset: 'sanitized-research-fixture', productionReady: false,
  generatedOn: '2026-10-30', categories, chapters,
  documents: articles.filter(article => !article.redirect).map(article => ({
    id: article.id, title: article.title, chapterId: article.chapter, kind: article.kind || 'guide',
    status: article.status, description: article.description, markdown: article.markdown,
    blocks: article.blocks, source: article.source,
    relativeUrl: `/guides/${encodeURIComponent(article.id)}`, relatedIds: article.related,
    sanitized: true,
  })),
};
await mkdir(new URL('../data/', import.meta.url), { recursive: true });
await writeFile(new URL('../data/knowledge-corpus.json', import.meta.url), JSON.stringify(corpus, null, 2) + '\n');
console.log(`Exported ${corpus.documents.length} sanitized documents; productionReady=false.`);
