# 使用与来源说明

本仓库为脱敏研究交接副本，不代表平台官方项目。品牌、商标及原创素材的权利属于各自权利人；公开交接不授予额外的品牌使用或再分发许可。第三方依赖以其原许可证为准。

- Three.js：MIT；保留于 public/assets/brand/THREE-LICENSE.txt。
- Noto Sans SC 标题子集：OFL，保留于 public/fonts/OFL-NotoSansSC.txt。
- GSAP / @gsap/react：GSAP Standard License，https://gsap.com/standard-license/ 。
- React、Vite、Phosphor 图标：沿用各依赖包的原许可。

不包含真实后台截图、联系二维码、原始内部文档或原仓库历史。
