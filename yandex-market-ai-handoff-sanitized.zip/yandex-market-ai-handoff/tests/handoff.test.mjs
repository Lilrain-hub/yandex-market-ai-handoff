import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { articles, chapters, questions, knowledgeSearchIndex } from '../src/knowledge-data.js';
import { navigation } from '../src/navigation.js';
import { searchIndex, safeHref, markdownBlocks, targetPath } from '../src/knowledge-utils.js';
import { parseLocation } from '../src/useKnowledgeNavigation.js';

test('all preserved navigation and related IDs resolve without a production data store', () => {
  const ids = new Set(articles.map(a => a.id));
  assert.equal(ids.size, articles.length);
  const check = target => {
    if (target.type === 'article') assert.ok(ids.has(target.id));
    if (target.type === 'chapter') assert.ok(chapters.some(c => c.id === target.id));
    assert.ok(targetPath(target).startsWith('/'));
  };
  for (const menu of navigation) { check(menu.featured.target); for (const group of menu.groups) for (const item of group.items) check(item.target); }
  for (const article of articles) for (const id of article.related) assert.ok(ids.has(id));
  for (const q of questions) assert.ok(ids.has(q.article));
});
test('search works on sanitized knowledge and stable article routes remain valid', () => {
  assert.ok(searchIndex(knowledgeSearchIndex,'FBS 仓库').some(a => a.id === 'shipping-3'));
  assert.deepEqual(searchIndex(knowledgeSearchIndex,'没有这个关键词-xxx'), []);
  assert.equal(parseLocation({pathname:'/guides/start-2',search:''}).id,'start-2');
});
test('all article image blocks use the sanitized placeholder and have a local asset', async () => {
  let count = 0;
  for (const article of articles) for (const block of article.blocks.filter(b => b.type === 'image')) {
    count++; assert.equal(block.src,'/assets/guides/guide-placeholder.svg');
    await access(new URL(`../public${block.src}`,import.meta.url));
  }
  assert.ok(count > 10);
});
test('public corpus contains the same nonredirect article IDs with traceable relative URLs', async () => {
  const corpus=JSON.parse(await readFile(new URL('../data/knowledge-corpus.json',import.meta.url),'utf8'));
  assert.equal(corpus.productionReady,false);
  assert.deepEqual(corpus.documents.map(a=>a.id),articles.filter(a=>!a.redirect).map(a=>a.id));
  assert.ok(corpus.documents.every(d=>d.sanitized && d.relativeUrl.startsWith('/guides/')));
});
test('Markdown remains inert and unsafe URL protocols are rejected', () => {
  for (const s of ['javascript:alert(1)','data:text/html,test','//untrusted.example']) assert.equal(safeHref(s),null);
  assert.ok(markdownBlocks('<script>alert(1)</script>').every(b=>b.type==='paragraph'));
});
