// Public sanitized research fixture; not a production policy source.
export const sellerSource = {
  "title": "Yandex Market 卖家运营中心",
  "suppliedDate": "2026-10-30",
  "sections": {
    "1.1": {
      "title": "平台介绍",
      "markdown": "Yandex Market 隶属于俄罗斯最大互联网集团 Yandex，依托搜索引擎的导流能力，平台月活跃用户超 2000 万，用户覆盖俄罗斯全境。2018 年与俄罗斯最大的联邦银行 Sberbank 达成合作，获得数亿美元投资优化物流、支付及平台升级，是进军俄罗斯及东欧市场的重要选择。\n\n- 平台前台商城：[market.yandex.ru](https://market.yandex.ru/)\n- 卖家登录后台：[partner.market.yandex.com](https://partner.market.yandex.com/welcome/crossborder)\n- 卖家知识库（官方中文，操作问题可先在此查询）：[官方中文教程入口](https://yandex.ru/support/global-marketplace/zh/introduction/)"
    },
    "1.2": {
      "title": "入驻要求",
      "markdown": "- 无需流水，无需保证金或押金\n- **入驻主体要求：企业、个体工商户**；中国大陆或中国香港企业营业执照均可\n- 企业营业执照注册需满 1 个月以上（含 1 个月）；企业经营状态为存续\n- 1 个营业执照可注册 1 个 Yandex Market 店铺\n- 回款支持人民币（CNY）\n- 多店铺入驻：各店铺填写的微信号需不同、营业执照法人需独立，以免关联；建议不同店铺使用不同网络环境（IP 隔离）"
    },
    "1.3": {
      "title": "店铺运营注意要点",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "1.4": {
      "title": "平台禁售规则",
      "markdown": "平台禁售清单：[官方禁售清单](https://yandex.ru/support/global-marketplace/zh/assortment/restrictions/)。\n\n示例服务商 物流渠道另有违禁品清单（易燃易爆、液体、纯电池、食品、药品等），发货前请对照《示例服务商 物流产品说明》，或向客服索取最新清单。"
    },
    "1.5": {
      "title": "入驻流程",
      "markdown": "**入驻主流程**：了解入驻要求 → 注册店铺 → 配置仓库物流 → 上架产品 → 配置 示例服务商-LIANLIAN 收款 → 开始销售。\n\n![入驻主流程图](https://example.invalid/guide-image/002)"
    },
    "1.6": {
      "title": "店铺注册与激活",
      "markdown": "### 必看 · 注册激活三件事\n\n完成店铺注册与激活，需要依次做好以下三件事：\n\n1. 注册店铺：使用 Yandex ID 注册 Yandex Market 店铺（详见下方「一」，配分步截图）。\n2. 设置 FBS 仓库：激活前需至少上传 1 个产品，并优先设置 FBS 仓库（详见下方「二」，配流程图）。\n3. 选择支付伙伴：收款方式请选择 示例服务商-LIANLIAN，回款将经由 示例服务商 与您结算（详见下方「三」）。\n\n\n\n\n\n### **一、注册店铺**\n\n使用 Yandex ID 注册店铺，全程约 10 分钟，按以下步骤操作：\n\n(入驻链接：[partner.market.yandex.com/welcome/crossborder\\_cn](https://partner.market.yandex.com/welcome/crossborder_cn))\n\n**步骤一：点击“与我们一起销售”注册帐户**\n\n![步骤1 打开入驻链接后的官网首页](https://example.invalid/guide-image/004)\n\n**步骤二：点击 Create ID 创建 Yandex ID（Yandex ID 即 Yandex 邮箱，建议使用 Yandex 邮箱注册店铺）。**\n\n![步骤2 注册Yandex ID](https://example.invalid/guide-image/005)\n\n**步骤三：填写手机号（区号填 +86）与姓名。**\n\n![步骤3 填写手机号与姓名](https://example.invalid/guide-image/006)\n\n**步骤四：设置验证方式，可点击 Not now 跳过。**\n\n![步骤4 验证方式设置](https://example.invalid/guide-image/007)\n\n**步骤五：登入账户并填写店铺名称（仅支持英文或俄文）。**\n\n![步骤5 登入并填写店铺名称](https://example.invalid/guide-image/008)\n\n**步骤六：注册国家与仓库均选 China，勾选产品类目，公司网址可跳过。**\n\n![步骤6 国家仓库与类目](https://example.invalid/guide-image/009)\n\n**步骤七：通过人机验证后点击 Confirm and submit，收到邮件即注册成功。**\n\n![步骤7 提交审核并确认注册成功](https://example.invalid/guide-image/010)\n\n**步骤八：在后台「法律信息」填写公司信息并上传营业执照与法人身份证。**\n\n![步骤8 填写法律信息](https://example.invalid/guide-image/011)\n\n**步骤九：进入卖家后台，按四步待办依次完成（合同 → 商品上传 → FBS 仓库 → 销售）。**\n\n![步骤9 进入卖家后台](https://example.invalid/guide-image/012)\n\n**步骤十：点击右上角店铺名称，在「帐户和商店」查看 Business ID 与 Shop ID。**\n\n![步骤10 查看ShopID与BusinessID](https://example.invalid/guide-image/013)\n\n### **二、设置 FBS 仓库**\n\n激活前需至少上传 1 个产品，并设置 FBS 仓库。激活路径：至少上传 1 个产品 → 设置 FBS 仓库 → 为上传的产品添加库存 → 平台质量部门检测通过后，开通店铺营销权限。\n\n注意：激活时先选择直发（FBS）模式完成激活；店铺激活成功后，可再创建 FBP 或本土发货模式（详见第四章）。\n\n仓库设置流程（每日订单处理能力上限默认 80 单，可按需调整）：\n\n第 1 步：点击仓库设置按钮，即可开始创建仓库页面。\n\n![第 1 步 · 点击仓库设置按钮：在后台「欢迎来到 Yandex 市场」页面点击前往仓库设置](https://example.invalid/guide-image/014)\n\n第 2 步：填写仓库具体信息（工作流程按 9:00–21:00 设置，每日订单处理能力上限默认 80 单，可按实际处理能力调整）。\n\n![第 2 步 · 填写仓库具体信息：名称、联系电话、联系人、地区邮编、街道地址，日订单处理量最多 80 单/每日](https://example.invalid/guide-image/015)\n\n第 3 步：选择运输方式及揽收点，根据仓库位置选择距离最近的揽收点。\n\n![第 3 步 · 选择运输方式及揽收点：三种运输交付模式，系统自动定位最近揽收服务点](https://example.invalid/guide-image/016)\n\n第 4 步：查看确认揽收点信息内容，确认无误后保存。\n\n![第 4 步 · 查看确认揽收点信息：服务商名称、地址、营业时间及联系方式，确认后点击选择](https://example.invalid/guide-image/017)\n\n第 5 步：选择发货计划时间，建议按实际发货节奏选择。\n\n![第 5 步 · 选择发货计划时间：备货周期最长可选七日后，设置每周实际工作时间及休息日](https://example.invalid/guide-image/018)\n\n### **三、选择 示例服务商-LIANLIAN 作为支付伙伴**\n\n收款方式选择 示例服务商-LIANLIAN 后，按以下流程完成签约与激活（回款规则详见 2.1）：\n\n1. 卖家填写公司信息，提交审核\n2. 平台将审核结果发送至 示例服务商-LIANLIAN\n\n4. 卖家店铺合同自动生效"
    },
    "1.7": {
      "title": "Yandex 邮箱注册",
      "markdown": "注册入口：[mail.yandex.com](https://mail.yandex.com)。建议使用 Yandex 邮箱注册店铺，也可使用其他邮箱。"
    },
    "2.1": {
      "title": "回款政策",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.2": {
      "title": "资料提交",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.3": {
      "title": "回款流程与账单界面",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.4": {
      "title": "平台佣金",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.5": {
      "title": "积分核算规则",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.6": {
      "title": "物流费用",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "2.7": {
      "title": "回款额计算",
      "markdown": ""
    },
    "2.8": {
      "title": "平台费用明细",
      "markdown": ""
    },
    "2.9": {
      "title": "订单回款说明",
      "markdown": ""
    },
    "3.1": {
      "title": "产品上架",
      "markdown": "**如何把其他电商平台的产品一键搬运至 Yandex Market 店铺**：\n\n- 打开卖家端首页，点击「从其他电商平台迁移」；或点击「产品 → 目录列表 → 上传商品 → 从其他电商平台」\n- 选择 OZON 或 Wildberries，填写对应平台的 Client ID 和 API 密钥，点击连接即可\n\n新店铺上架限额为 3,000 个商品（以后台实际提示为准），批量迁移可能一次性消耗完限额。\n\n若迁移时勾选了\"价格\"选项，源平台（OZON / WB）价格一旦调整，Yandex Market 上的商品价格会同步更新；如需自主定价，请勿勾选价格同步。\n\n上架第一步：进入卖家后台「商品 → 目录 → 上传商品」：\n\n![商品菜单中的上传商品按钮位置](https://example.invalid/guide-image/021)\n\n点击「上传商品」后，选择「从其他电商平台」一键迁移：\n\n![上传和更新产品页面，从其他电商平台入口](https://example.invalid/guide-image/022)\n\n选择 OZON 或 Wildberries，填写对应平台的 Client ID 和 API 密钥，点击「连接」：\n\n![Ozon 与 Wildberries 集成设置，填写 Client ID 与 API 密钥](https://example.invalid/guide-image/023)"
    },
    "3.2": {
      "title": "店铺产品上架限额",
      "markdown": ""
    },
    "3.3": {
      "title": "品牌授权",
      "markdown": "平台对品牌商品要求严格：\n\n- 销售品牌商品，请准备品牌授权文件、进货发票等证明材料\n- 若商品被平台提示\"真实性存在质疑\"，请通过后台「消息图标 → 支持 → 创建案例」联系客服，按要求提交证明文件（如发票、授权文件等），客服会告知所需材料清单\n\n授权文件在后台「商品 → 文件」中上传：\n\n![商品菜单中的文件入口](https://example.invalid/guide-image/024)\n\n进入文件页后点击「添加」：\n\n![文件页面，点击添加按钮](https://example.invalid/guide-image/025)\n\n选择品牌、类型（许可协议或版权持有人同意）、有效期，上传扫描副本后保存：\n\n![添加文件表单：品牌、类型、有效期与扫描副本](https://example.invalid/guide-image/026)"
    },
    "3.4": {
      "title": "卖家后台切换语言",
      "markdown": "后台支持切换界面语言：点击右上角头像 → 设置 → 语言 → 选择「中文」。平台操作问题也可先在[卖家知识库](https://yandex.ru/support/global-marketplace/zh/introduction/)查询。\n\n![右上角头像菜单中将界面语言切换为中文](https://example.invalid/guide-image/027)"
    },
    "4.1": {
      "title": "发货模式概览",
      "markdown": "Yandex Market 支持三种发货模式：\n\n| 模式                  | 适合卖家             | 说明                               |\n| ------------------- | ---------------- | -------------------------------- |\n| FBS 自发货（直发）         | 无货源 / 初期试水卖家     | 出单后将货物发至 示例服务商 揽收点仓库，从中国发货，支持一件代发 |\n| FBP 半托管             | 有一定囤货能力 / 服饰配饰卖家 | 货物提前运至 示例服务商 黑河边境仓，出单后由边境仓直接发货    |\n| 本土发货（FBS Last Mile） | 货物已在俄罗斯的卖家       | 出单后将货物发送至就近的 Yandex 揽收点          |\n\n重要：店铺激活时，请先选择直发（FBS）模式完成激活；店铺激活成功后，可再创建 FBP 或本土发货模式。一个店铺可以创建多个仓库。\n\n\n\n![](https://example.invalid/guide-image/028)"
    },
    "4.2": {
      "title": "FBP 半托管模式",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "4.3": {
      "title": "FBS 自发货模式",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    "4.4": {
      "title": "本土发货模式（FBS Last Mile）",
      "markdown": "- 适合货物已在俄罗斯的卖家，出单后将货物发送至就近的 Yandex 揽收点\n- 本土收货点列表：[官方收货点列表](https://yandex.ru/support/global-marketplace/zh/orders/fbs/logistics)\n- 费用构成见 2.6「物流费用」"
    },
    "5.1": {
      "title": "仓库设置流程",
      "markdown": "![FBS 仓库设置指引封面](https://example.invalid/guide-image/029)\n\n按以下 5 步完成仓库设置：\n\n- 登录卖家后台，点击「仓库设置 → 添加」\n- 填写仓库具体信息（日订单处理数量，上限为每日 80 单）\n- 选择运输方式及揽收点（选择 示例服务商 揽收点，如 示例服务商-SHENZHEN07）\n- 查看并确认揽收点信息\n- 选择发货计划时间"
    },
    "5.2": {
      "title": "自发货物流设置",
      "markdown": "自发货模式的运输方式与物流商，均在「仓库设置 → 更改地点」中配置：缩小地图可显示更多物流商点位，选择对应物流商后保存。\n\n![后台导航：包裹与仓库菜单](https://example.invalid/guide-image/030)\n\n![更改送货市场：选择物流方式](https://example.invalid/guide-image/031)\n\n![供货管理：选择仓库与送货方式（地图选物流商）](https://example.invalid/guide-image/032)\n\n![供货日历：设置工作时间](https://example.invalid/guide-image/033)\n\n![供应管理：库存与供货时间](https://example.invalid/guide-image/034)\n\n**Extra Small（超级轻小件）商品需单独设置仓库**：重量 ≤500 克、货值 ≤1500 卢布的商品走 Extra Small 渠道。正确设置方法：① 新建一个仓库（后台「仓库 → 添加」）；② 为新仓库选择 Extra Small 优选配送方式；③ 将符合条件的产品转移到新仓库，并隐藏原仓库中的这些商品。若商品符合条件仍报错，请联系客服检查。"
    },
    "5.3": {
      "title": "揽收点说明",
      "markdown": "示例服务商 自营操作中心：东莞仓（华南）、义乌仓（华东）、黑河边境仓（一件代发）、深圳平湖仓（自贴单）。\n\n全国 60+ 揽收点地址及联系方式，请向 示例服务商 客服索取最新版《示例服务商 物流产品说明》。"
    },
    "7.1": {
      "title": "广告促销活动",
      "markdown": "平台促销活动（如 Bestsellers）报名教程，请向 示例服务商 客服获取最新版。\n\n平台政策提醒（2026 年 4 月 2 日起）：Yandex Market 将在卖家的销售提升活动（boost）中启用定价策略——部分出价将转移到平台补贴，平台以积分形式返还价差。如需关闭定价策略，请编辑自己的广告活动。"
    },
    "returns": {
      "markdown": "本章解决：买家退货规则与退款对回款的影响。\n\n- 平台退货退款政策（官方）：[买家退货与退款规则](https://yandex.ru/support/global-marketplace/zh/orders/returns/buyer-s-rights)\n- 买家可退货周期：订单签收后 10–15 天内；填写了有效期 / 保修期的商品，在有效期内均可退货\n- 退款金额会在回款公式中扣除（见 2.7），请在定价与售后处理中预留空间"
    },
    "support": {
      "markdown": "本章解决：有问题找谁、怎么提交。\n\n**联系平台客服**：店铺后台右上角「消息图标 → 支持 → 创建案例」，用俄语或英语描述问题并附上截图。\n\n常见需要开 case 的场景：商品真实性申诉、关联账户申诉、质量指数申诉、回款异常查询。\n\n**联系 示例服务商 客服**：\n\n\n\n\n\n\n![](https://example.invalid/guide-image/035)"
    }
  },
  "faqs": [
    {
      "number": 1,
      "title": "注册后，如何获取店铺 ID？",
      "markdown": "店铺 ID（216 或 14 开头）可在卖家后台个人中心查看；示例服务商-LIANLIAN 收款绑定与资料提交均需要此 ID。"
    },
    {
      "number": 2,
      "title": "入驻时选择了 FBP 发货模式，导致店铺无法激活，如何补加 FBS？",
      "markdown": "激活时需先选择直发（FBS）模式（见 1.6）。若已误选 FBP，请在仓库设置中新增 FBS 仓库并添加库存，再联系平台客服处理。\n\n![设置中您的商店列表与添加按钮](https://example.invalid/guide-image/036)"
    },
    {
      "number": 3,
      "title": "从 OZON / WB 迁移的商品，价格经常自动更新？",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    {
      "number": 4,
      "title": "上传产品后，目录界面报错\"无法运送至所选地点\"？",
      "markdown": "常见原因：\n\n① 商品带电带磁却选择了空运——进入「仓库设置 → 更改地点」，重新选择运输方式，缩小地图找到对应物流商点位后保存；\n\n② 商品尺寸填写不正确；\n\n③ 类目填写不正确——重新确认类目并保存。均排除后仍无法上架，请通过「消息 → 支持 → 创建案例」联系平台客服。"
    },
    {
      "number": 5,
      "title": "目录内商品报错\"被隐藏\"？",
      "markdown": "该商品不适合放在轻小件仓库。请进入「仓库设置 → 更改地点 → 缩小地图」，重新选择运输方式和物流商地址（注意不要选到轻小件地址）。Extra Small 商品的正确设置见 5.2。"
    },
    {
      "number": 6,
      "title": "店铺提示\"关联账户\"？",
      "markdown": "两种可能：① 同时运营相同营业执照的店铺（无法申诉）；② 不同营业执照上架了相同或相似的产品（修改产品类目，避免与其他店铺重复，再用需解封的店铺联系客服申诉）。"
    },
    {
      "number": 7,
      "title": "因质量指数过低，产品被隐藏？",
      "markdown": "一般由延迟发货或取消多笔订单导致，店铺会被封禁 7 天并产生罚款。请联系客服说明原因尝试申诉，或等待自行解封。"
    },
    {
      "number": 8,
      "title": "店铺产品被隐藏，提示对真实性存在质疑？",
      "markdown": "平台对品牌要求严格。请通过「消息 → 支持 → 创建案例」提交产品真实性证明文件（发票、授权文件等）。品牌商品请提前准备品牌上架文件（见 3.2）。"
    },
    {
      "number": 9,
      "title": "海外仓发货的取件如何操作？",
      "markdown": "首先确认店铺已选择 示例服务商 作为支付合作伙伴，然后向招商部门索取取件申请书，我们会指导填写并回传；申请书经 示例服务商 盖章后，携带取件书和取件二维码前往取件。"
    },
    {
      "number": 10,
      "title": "卢布店铺可以迁移为人民币店铺吗？",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    },
    {
      "number": 11,
      "title": "为什么没有收到回款？",
      "markdown": "## 脱敏研究示例\n\n该主题的商业结算、费率、合同与运营参数未包含在公开交接版中。请由后端加载经过授权和复核的正式知识。此文本只用于验证文章展示、搜索和知识切分，不作为实际经营依据。"
    }
  ],
  "glossary": [
    {
      "term": "FBS 自发货（直发）",
      "description": "出单后从中国发货的模式，新店铺先用它完成激活"
    },
    {
      "term": "FBP 半托管",
      "description": "货物提前入 示例服务商 黑河边境仓，出单后由边境仓直接发货"
    },
    {
      "term": "FBS Last Mile（本土发货）",
      "description": "货物已在俄罗斯，出单后发往 Yandex 揽收点"
    },
    {
      "term": "Shop ID（店铺 ID）",
      "description": "店铺编号，216 或 14 开头，收款绑定与资料提交必用"
    },
    {
      "term": "Business ID（商家 ID）",
      "description": "商家编号，与 Shop ID 同在后台右上角头像菜单查看"
    },
    {
      "term": "Market 服务费",
      "description": "平台按类目收取的佣金，以官方佣金表为准"
    },
    {
      "term": "示例服务商 服务费 1.3%",
      "description": "示例服务商 收取的服务费（后台显示 3%，实际 1.3%）"
    },
    {
      "term": "连连提现手续费 1.3%",
      "description": "经 示例服务商-LIANLIAN 通道回款时收取的提现手续费"
    },
    {
      "term": "Extra Small",
      "description": "超级轻小件渠道（≤500g 且货值 ≤1500₽），需单独设仓"
    },
    {
      "term": "GTA",
      "description": "示例服务商 自营物流渠道系列（Super Express / Express / Economy）"
    },
    {
      "term": "质量指数",
      "description": "平台对店铺表现的评分，延迟发货 / 取消订单会拉低并致封禁"
    },
    {
      "term": "积分",
      "description": "平台发放的折扣补偿，可抵扣物流、推广等费用"
    },
    {
      "term": "揽收点",
      "description": "示例服务商 收货仓库网点（东莞 / 义乌 / 黑河 / 深圳平湖等）"
    },
    {
      "term": "MKAD",
      "description": "莫斯科环城公路，本土发货跨区域配送费的分界线"
    }
  ],
  "images": {
    "https://example.invalid/guide-image/001": {
      "src": null,
      "alt": "",
      "width": 820,
      "height": 973
    },
    "https://example.invalid/guide-image/002": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/003": {
      "src": null,
      "alt": "",
      "width": 480,
      "height": 480
    },
    "https://example.invalid/guide-image/004": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/005": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/006": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/007": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/008": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/009": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/010": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/011": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/012": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/013": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/014": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/015": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/016": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/017": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/018": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/019": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/020": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/021": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/022": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/023": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/024": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/025": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/026": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/027": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/028": {
      "src": null,
      "alt": "",
      "width": 1062,
      "height": 1312
    },
    "https://example.invalid/guide-image/029": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/030": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/031": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/032": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/033": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/034": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/035": {
      "src": null,
      "alt": "",
      "width": 1026,
      "height": 983
    },
    "https://example.invalid/guide-image/036": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    },
    "https://example.invalid/guide-image/037": {
      "src": "/assets/guides/guide-placeholder.svg",
      "alt": "界面位置示例（真实后台截图已从公开交接版移除）",
      "width": 1200,
      "height": 760
    }
  }
};
