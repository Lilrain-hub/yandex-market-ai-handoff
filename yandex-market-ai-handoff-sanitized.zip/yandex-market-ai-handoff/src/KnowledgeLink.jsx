import { targetPath } from './knowledge-utils.js';

// Real links support copy, new-tab opening and browser history as well as SPA navigation.
export function KnowledgeLink({ target, onNavigate, children, className = '', ...props }) {
  return <a className={className} href={targetPath(target)} onClick={event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    event.currentTarget.closest('.kb-mobile-topics')?.removeAttribute('open');
    onNavigate(target);
  }} {...props}>{children}</a>;
}
