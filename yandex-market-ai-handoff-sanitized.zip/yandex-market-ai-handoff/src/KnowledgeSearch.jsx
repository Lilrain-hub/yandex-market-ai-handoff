import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowUpRight, BookOpenText, MagnifyingGlass, X } from '@phosphor-icons/react';
import { articles, knowledgeSearchIndex } from './knowledge-data.js';
import { searchIndex } from './knowledge-utils.js';
import { KnowledgeLink } from './KnowledgeLink.jsx';
import './knowledge-pages.css';

const kinds = [['all', '全部'], ['guide', '操作指南'], ['question', '常见问题'], ['resource', '工具与资料'], ['term', '术语']];
export function KnowledgeSearch({ query, setQuery, onClose, onNavigate }) {
  const ref = useRef(null);
  const input = useRef(null);
  const [kind, setKind] = useState('all');
  useEffect(() => {
    const active = document.activeElement;
    const previous = document.body.style.overflow;
    ref.current.showModal(); document.body.style.overflow = 'hidden'; input.current.focus();
    return () => { document.body.style.overflow = previous; if (active?.isConnected) active.focus({ preventScroll: true }); };
  }, []);
  const results = useMemo(() => searchIndex(knowledgeSearchIndex, query, kind), [query, kind]);
  const allResults = useMemo(() => searchIndex(knowledgeSearchIndex, query), [query]);
  const navigate = target => { onClose(); onNavigate(target); };
  return <dialog className="kb-search-dialog" ref={ref} aria-labelledby="kb-search-heading" onCancel={event => { event.preventDefault(); onClose(); }} onClick={event => { if (event.target === ref.current) onClose(); }}>
    <div className="kb-search-top"><span>YandexMarket 卖家百科</span><button type="button" onClick={onClose} aria-label="关闭搜索"><X size={23} /></button></div>
    <h2 id="kb-search-heading">今天想完成哪件事？</h2>
    <form className="kb-search-input" role="search" onSubmit={event => event.preventDefault()}><MagnifyingGlass size={23} /><input ref={input} aria-label="搜索知识库" value={query} onChange={event => setQuery(event.target.value)} placeholder="搜索操作、报错、术语或资料" /><button type="button" aria-label="清空搜索" disabled={!query} onClick={() => setQuery('')}><X size={18} /></button></form>
    {query.trim() ? <><div className="kb-filters" role="group" aria-label="搜索结果类型">{kinds.map(([id, name]) => <button type="button" key={id} aria-pressed={kind === id} onClick={() => setKind(id)}>{name}<span>{id === 'all' ? allResults.length : allResults.filter(item => item.type === id).length}</span></button>)}</div>
      <p className="kb-result-count" role="status">找到 {results.length} 个相关结果</p>
      <div className="kb-search-results">{results.map(item => <KnowledgeLink target={item.target} key={item.id} onNavigate={navigate}><span className="kb-search-result-kind">{kinds.find(([id]) => id === item.type)?.[1]} · {item.label}{item.status === 'pending' ? ' · 整理中' : ''}</span><strong>{item.title}</strong><p>{item.description}</p><ArrowUpRight size={20} /></KnowledgeLink>)}</div>
      {!results.length && <div className="kb-search-empty"><MagnifyingGlass size={32} /><h3>换一个说法试试</h3><p>例如“价格自动变了”“回款没到”“轻小件仓库”。</p><KnowledgeLink target={{ type: 'library' }} onNavigate={navigate}>浏览全部指南<ArrowUpRight size={17} /></KnowledgeLink></div>}
    </> : <><p className="kb-result-count">从常用任务开始</p><div className="kb-search-suggestions">{articles.filter(item => item.featured).map(item => <KnowledgeLink key={item.id} target={{ type: 'article', id: item.id }} onNavigate={navigate}><BookOpenText size={18} /><span>{item.title}</span><ArrowUpRight size={18} /></KnowledgeLink>)}</div><div className="kb-search-bottom"><KnowledgeLink target={{ type: 'library' }} onNavigate={navigate}>全部运营指南<ArrowUpRight size={17} /></KnowledgeLink><KnowledgeLink target={{ type: 'faq' }} onNavigate={navigate}>常见问题<ArrowUpRight size={17} /></KnowledgeLink><KnowledgeLink target={{ type: 'glossary' }} onNavigate={navigate}>术语速查<ArrowUpRight size={17} /></KnowledgeLink></div></>}
  </dialog>;
}
