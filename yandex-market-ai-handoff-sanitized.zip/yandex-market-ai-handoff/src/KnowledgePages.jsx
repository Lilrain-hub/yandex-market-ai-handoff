import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, BookOpenText, Check, CheckCircle, Copy, Files, List, MagnifyingGlass, Question, Truck } from '@phosphor-icons/react';
import { articles, categories, chapters, chapterArticles, findArticle, glossary, questions, resources } from './knowledge-data.js';
import { KnowledgeBody } from './KnowledgeBody.jsx';
import { KnowledgeLink } from './KnowledgeLink.jsx';
import './knowledge-pages.css';

function Sidebar({ route, onNavigate }) {
  const activeChapter = route.type === 'article' ? findArticle(route.id)?.chapter : route.id;
  return <aside className="kb-sidebar" aria-label="知识库目录">
    <KnowledgeLink target={{ type: 'library' }} onNavigate={onNavigate} className={`kb-sidebar-home${route.type === 'library' ? ' is-active' : ''}`}><BookOpenText size={20} />全部运营指南</KnowledgeLink>
    {categories.map(category => <section className="kb-sidebar-group" key={category.id}>
      <h2>{category.name}</h2>
      {category.chapters.filter(id => !['faq', 'documents'].includes(id)).map(id => {
        const chapter = chapters.find(item => item.id === id);
        const active = id === activeChapter;
        return <div className={`kb-sidebar-topic${active ? ' is-active' : ''}`} key={id}>
          <KnowledgeLink target={{ type: 'chapter', id }} onNavigate={onNavigate} aria-current={route.type === 'chapter' && active ? 'page' : undefined}>{chapter.name}<span>{chapterArticles(id).length}</span></KnowledgeLink>
          {active && <ul>{chapterArticles(id).map(article => <li key={article.id}><KnowledgeLink target={{ type: 'article', id: article.id }} onNavigate={onNavigate} aria-current={route.type === 'article' && route.id === article.id ? 'page' : undefined}>{article.title}</KnowledgeLink></li>)}</ul>}
        </div>;
      })}
    </section>)}
    <div className="kb-sidebar-tools">
      {[['faq', '常见问题', Question], ['resources', '工具与资料', Files], ['glossary', '术语速查', BookOpenText]].map(([type, label, Icon]) =>
        <KnowledgeLink key={type} target={{ type }} onNavigate={onNavigate} aria-current={route.type === type || (type === 'faq' && activeChapter === 'faq') ? 'page' : undefined}><Icon size={18} />{label}<ArrowUpRight size={15} /></KnowledgeLink>)}
    </div>
  </aside>;
}

function ArticleCard({ article, onNavigate, number }) {
  return <KnowledgeLink target={{ type: 'article', id: article.id }} onNavigate={onNavigate} className="kb-article-card">
    <span className="kb-card-icon">{number !== undefined ? String(number + 1).padStart(2, '0') : <BookOpenText size={21} />}</span>
    <span className="kb-card-body"><span className="kb-card-meta">{article.kind === 'question' ? '问题解答' : article.status === 'pending' ? '内容整理中' : `${article.readMinutes} 分钟阅读`}</span><strong>{article.title}</strong><span>{article.description}</span></span><ArrowUpRight className="kb-card-arrow" size={21} />
  </KnowledgeLink>;
}

function PageIntro({ eyebrow, title, description, children }) {
  return <header className="kb-page-intro"><span className="kb-eyebrow">{eyebrow}</span><h1 tabIndex={-1}>{title}</h1><p>{description}</p>{children}</header>;
}

function LibraryPage({ onNavigate }) {
  const [filter, setFilter] = useState('all');
  const topicList = chapters.filter(chapter => !['faq', 'documents'].includes(chapter.id) && (filter === 'all' || chapter.category === filter));
  return <>
    <PageIntro eyebrow="运营指南" title="从一个任务，找到下一步。" description="开店、上架、发货、收款。按经营阶段浏览，或直接进入你要完成的事。" />
    <div className="kb-task-shortcuts">{[
      ['start-2', '注册第一家店', '从账户创建开始', BookOpenText], ['product-0', '导入我的商品', '连接源平台目录', Files],
      ['shipping-3', '设置发货仓库', '配好物流与库存', Truck], ['finance-2', '查询回款状态', '找到财务记录', CheckCircle],
    ].map(([id, title, caption, Icon]) => <KnowledgeLink key={id} target={{ type: 'article', id }} onNavigate={onNavigate}><Icon size={24} /><strong>{title}</strong><span>{caption}</span><ArrowUpRight size={17} /></KnowledgeLink>)}</div>
    <div className="kb-section-heading"><h2>按专题浏览</h2><span>{topicList.length} 个专题</span></div>
    <div className="kb-filters" role="group" aria-label="筛选运营指南分类">{[{ id: 'all', name: '全部' }, ...categories].map(category => <button key={category.id} type="button" aria-pressed={filter === category.id} onClick={() => setFilter(category.id)}>{category.name}</button>)}</div>
    <div className="kb-topic-grid" aria-live="polite">{topicList.map(chapter => {
      const items = chapterArticles(chapter.id);
      return <KnowledgeLink key={chapter.id} target={{ type: 'chapter', id: chapter.id }} onNavigate={onNavigate} className="kb-topic-card"><span>{categories.find(item => item.id === chapter.category)?.name}</span><h3>{chapter.name}</h3><p>{chapter.description}</p><div><span>{items.length} 篇指南</span><ArrowUpRight size={21} /></div></KnowledgeLink>;
    })}</div>
    <div className="kb-help-strip"><Question size={26} /><div><strong>已经遇到具体问题？</strong><p>从报错、疑问和常见卡点出发，找到对应解答。</p></div><KnowledgeLink target={{ type: 'faq' }} onNavigate={onNavigate}>查看常见问题<ArrowRight size={18} /></KnowledgeLink></div>
  </>;
}

function ChapterPage({ chapter, onNavigate }) {
  const items = chapterArticles(chapter.id);
  return <><PageIntro eyebrow={categories.find(item => item.id === chapter.category)?.name} title={chapter.name} description={chapter.description}><span className="kb-count-pill">{items.length} 篇指南</span></PageIntro>
    <div className="kb-article-list">{items.map((item, index) => <ArticleCard key={item.id} article={item} onNavigate={onNavigate} number={index} />)}</div>
    <div className="kb-help-strip"><BookOpenText size={24} /><div><strong>继续浏览相关专题</strong><p>从同一经营阶段找到其他操作指南。</p></div><KnowledgeLink target={{ type: 'library' }} onNavigate={onNavigate}>全部指南<ArrowRight size={18} /></KnowledgeLink></div></>;
}

function TableOfContents({ article, mobile = false }) {
  const links = [
    ...(article.before.length ? [{ id: 'article-before', text: '操作前准备' }] : []),
    ...article.blocks.filter(block => block.type === 'heading'),
    ...(article.complete ? [{ id: 'article-complete', text: '完成后检查' }] : []),
    { id: 'article-related', text: '相关指南' },
  ];
  const list = <nav aria-label={mobile ? '手机文章目录' : '本页目录'}>{links.map(item => <a href={`#${item.id}`} key={item.id} onClick={event => {
    event.preventDefault();
    if (mobile) event.currentTarget.closest('details')?.removeAttribute('open');
    history.replaceState(history.state, '', `#${item.id}`);
    // Let a collapsed mobile TOC finish layout before locating its target.
    requestAnimationFrame(() => {
      const target = document.getElementById(item.id);
      if (!target) return;
      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
      target.scrollIntoView({ behavior: 'instant', block: 'start' });
    });
  }}>{item.text}</a>)}</nav>;
  return mobile ? <details className="kb-mobile-toc"><summary><List size={18} />本页目录<span>{links.length} 项</span></summary>{list}</details> :
    <aside className="kb-toc"><strong>本页目录</strong>{list}<div className="kb-toc-source"><span>资料来源</span><p>{article.sourceTitle}</p><span>{article.source ? `原文 ${article.source}` : '教程索引'}</span></div></aside>;
}

function ArticlePage({ article, onNavigate }) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const siblings = chapterArticles(article.chapter);
  const position = siblings.findIndex(item => item.id === article.id);
  const related = (article.related.length ? article.related.map(findArticle) : siblings.filter(item => item.id !== article.id)).filter(Boolean).slice(0, 3);
  const resource = resources.find(item => item.name === article.resource);
  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), 2200);
    return () => clearTimeout(timer);
  }, [copied]);
  return <div className="kb-article-layout"><article className="kb-reading-article">
    <header className="kb-article-header" id="article-start"><span className="kb-eyebrow">{article.kind === 'question' ? '问题解答' : article.chapterName}</span>
      <h1 tabIndex={-1}>{article.title}</h1><p className="kb-article-lead">{article.description}</p>
      <div className="kb-article-meta"><span><BookOpenText size={15} />{article.status === 'pending' ? '内容整理中' : `${article.readMinutes} 分钟阅读`}</span><span>{article.status !== 'pending' && (article.blocks.some(block => block.type === 'image') ? '图文指南' : '操作参考')}</span>
        <button type="button" onClick={async () => { try { await navigator.clipboard.writeText(window.location.href); setCopied(true); setCopyError(false); } catch { setCopyError(true); } }}><Copy size={15} />{copied ? '链接已复制' : '复制链接'}</button>
      </div>{copyError && <p className="kb-copy-fallback" role="status">可复制浏览器地址栏中的链接分享这篇指南。</p>}
    </header>
    <TableOfContents article={article} mobile />
    {article.status === 'pending' ? <div className="kb-pending-note"><BookOpenText size={30} /><h2>这篇内容正在整理</h2><p>先从下方相关指南继续查找，工具与资料中心也提供了可用的参考入口。</p><KnowledgeLink target={{ type: 'resources' }} onNavigate={onNavigate}>查看工具与资料<ArrowUpRight size={18} /></KnowledgeLink></div> : <>
      {article.before.length > 0 && <section className="kb-preparation" id="article-before"><h2>操作前准备</h2><ul>{article.before.map(item => <li key={item}><Check size={17} />{item}</li>)}</ul></section>}
      <KnowledgeBody blocks={article.blocks} />
      {article.complete && <section className="kb-complete" id="article-complete"><CheckCircle size={24} /><div><h2>完成后检查</h2><p>{article.complete}</p></div></section>}
    </>}
    {resource && <KnowledgeLink target={{ type: 'resources', highlight: resource.name }} onNavigate={onNavigate} className="kb-inline-resource"><Files size={25} /><div><strong>{resource.name}</strong><span>{resource.purpose}</span></div><ArrowUpRight size={20} /></KnowledgeLink>}
    <div className="kb-source-note">根据《{article.sourceTitle}》{article.source ? ` ${article.source}` : ''}整理。操作界面以实际卖家后台为准。</div>
    <section className="kb-related" id="article-related"><div className="kb-section-heading"><h2>相关指南</h2><KnowledgeLink target={{ type: 'chapter', id: article.chapter }} onNavigate={onNavigate}>查看本专题<ArrowRight size={16} /></KnowledgeLink></div>
      <div className="kb-article-list">{related.map(item => <ArticleCard key={item.id} article={item} onNavigate={onNavigate} />)}</div>
    </section>
    <nav className="kb-prev-next" aria-label="前后篇导航">{[siblings[position-1], siblings[position+1]].map((item, i) => item ? <KnowledgeLink key={i} target={{ type: 'article', id: item.id }} onNavigate={onNavigate}><span>{i === 0 ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}{i === 0 ? '上一篇' : '下一篇'}</span><strong>{item.title}</strong></KnowledgeLink> : <div key={i} />)}</nav>
    <div className="kb-reading-help"><span>仍有疑问？</span><KnowledgeLink target={{ type: 'article', id: 'support-0' }} onNavigate={onNavigate}>查看平台支持入口<ArrowUpRight size={16} /></KnowledgeLink><KnowledgeLink target={{ type: 'glossary' }} onNavigate={onNavigate}>术语速查<ArrowUpRight size={16} /></KnowledgeLink></div>
  </article><TableOfContents article={article} /></div>;
}

function FaqPage({ onNavigate }) {
  const [tag, setTag] = useState('全部');
  const [query, setQuery] = useState('');
  const visible = questions.filter(item => (tag === '全部' || item.tag === tag) && `${item.title} ${item.context}`.toLowerCase().includes(query.toLowerCase().trim()));
  return <><PageIntro eyebrow="问题解答" title="你遇到的问题，从这里查。" description="从注册激活、商品上架到发货收款，按问题找到处理方法和相关教程。" />
    <label className="kb-filter-search"><MagnifyingGlass size={20} /><input aria-label="查找常见问题" value={query} onChange={event => setQuery(event.target.value)} placeholder="输入问题或报错关键词" /></label>
    <div className="kb-filters" role="group" aria-label="筛选常见问题">{['全部', ...new Set(questions.map(item => item.tag))].map(item => <button key={item} type="button" aria-pressed={tag === item} onClick={() => setTag(item)}>{item}</button>)}</div>
    <p className="kb-result-count" role="status">{visible.length} 个常见问题</p>
    <div className="kb-faq-collection">{visible.map(item => {
      const article = findArticle(item.article);
      return <details key={item.article}><summary><span className="kb-question-mark">?</span><strong>{item.title}</strong><span className="kb-faq-plus">+</span></summary>
        <div className="kb-faq-answer">{article.status === 'pending' ? <p>这项说明正在整理，可先查看相关指南与支持入口。</p> : <KnowledgeBody blocks={article.blocks} compact />}
          <div className="kb-faq-links"><KnowledgeLink target={{ type: 'article', id: item.article }} onNavigate={onNavigate}>打开问题详情<ArrowUpRight size={16} /></KnowledgeLink>{article.related.slice(0, 2).map(id => <KnowledgeLink key={id} target={{ type: 'article', id }} onNavigate={onNavigate}>{findArticle(id)?.title}<ArrowUpRight size={16} /></KnowledgeLink>)}</div>
        </div></details>;
    })}</div>{!visible.length && <p className="kb-empty-state">没有找到对应问题，可以换一个关键词，或使用顶部的全站搜索。</p>}</>;
}

function ResourcesPage({ onNavigate, highlight }) {
  const [filter, setFilter] = useState('all');
  useEffect(() => {
    if (!highlight) return;
    setFilter('all');
    requestAnimationFrame(() => document.getElementById(`kb-resource-${resources.findIndex(item => item.name === highlight)}`)?.scrollIntoView({ block: 'center' }));
  }, [highlight]);
  const list = resources.filter(item => filter === 'all' || item.group === filter);
  return <><PageIntro eyebrow="常用入口" title="工具与资料，顺手就能找到。" description="在线工具、平台规则和文件资料集中收录。每个入口标清用途与当前状态。" />
    <div className="kb-resource-feature"><Files size={30} /><div><span>常用在线工具</span><h2>跨境运费定价表</h2><p>按商品信息进入 示例服务商 运费试算工具。</p></div><a href={resources[1].href} target="_blank" rel="noopener noreferrer">打开工具<ArrowUpRight size={18} /></a></div>
    <div className="kb-filters" role="group" aria-label="筛选工具与资料">{[['all', '全部资料'], ['tools', '在线工具'], ['official', '官方参考'], ['files', '文件与视频']].map(([id, name]) => <button key={id} type="button" aria-pressed={filter === id} onClick={() => setFilter(id)}>{name}</button>)}</div>
    <div className="kb-resource-grid">{list.map(item => {
      const index = resources.indexOf(item);
      const Tag = item.href ? 'a' : 'div';
      return <Tag key={item.name} id={`kb-resource-${index}`} className={`kb-resource-card${highlight === item.name ? ' is-highlighted' : ''}`} {...(item.href ? { href: item.href, target: '_blank', rel: 'noopener noreferrer' } : {})}>
        <span className="kb-format">{item.format}</span><h2>{item.name}</h2><p>{item.purpose}</p><div><span>{item.href ? item.group === 'official' ? '查看原文' : '打开工具' : '资料待补充'}</span>{item.href && <ArrowUpRight size={19} />}</div>
      </Tag>;
    })}</div>
    <div className="kb-help-strip"><BookOpenText size={24} /><div><strong>需要分步操作说明？</strong><p>教程按任务独立整理，可从运营指南继续查找。</p></div><KnowledgeLink target={{ type: 'library' }} onNavigate={onNavigate}>浏览教程<ArrowRight size={18} /></KnowledgeLink></div>
  </>;
}

function GlossaryPage() {
  const [query, setQuery] = useState('');
  const list = glossary.filter(item => `${item.term} ${item.description}`.toLowerCase().includes(query.trim().toLowerCase()));
  return <><PageIntro eyebrow="阅读帮助" title="术语速查" description="先弄懂词的意思，再继续完成手上的操作。" />
    <label className="kb-filter-search"><MagnifyingGlass size={20} /><input aria-label="查找术语" value={query} onChange={event => setQuery(event.target.value)} placeholder="试试：FBS、Shop ID、积分" /></label>
    <dl className="kb-glossary">{list.map(item => <div key={item.term}><dt>{item.term}</dt><dd>{item.description}</dd></div>)}</dl>
    {!list.length && <p className="kb-empty-state">暂未收录这个术语，试试其他关键词。</p>}</>;
}

export function KnowledgePages({ route, onNavigate, onSearch }) {
  const mainRef = useRef(null);
  const article = route.type === 'article' ? findArticle(route.id) : null;
  const chapter = route.type === 'chapter' ? chapters.find(item => item.id === route.id) : null;
  const title = article?.title || chapter?.name || ({ library: '运营指南', faq: '常见问题', resources: '工具与资料', glossary: '术语速查' }[route.type]) || '未找到页面';
  useEffect(() => {
    document.title = `${title} · YandexMarket卖家百科`;
    mainRef.current?.querySelector('h1')?.focus({ preventScroll: true });
    if (window.location.hash) requestAnimationFrame(() => document.getElementById(window.location.hash.slice(1))?.scrollIntoView());
  }, [route.key, title]);
  return <main className="kb-workspace" id="knowledge-reading" ref={mainRef}>
    <div className="kb-breadcrumb-bar"><nav aria-label="面包屑导航"><KnowledgeLink target={{ type: 'home' }} onNavigate={onNavigate}>首页</KnowledgeLink><span>/</span>{(article || chapter) && <><KnowledgeLink target={{ type: 'library' }} onNavigate={onNavigate}>运营指南</KnowledgeLink><span>/</span></>}{article && <><KnowledgeLink target={{ type: 'chapter', id: article.chapter }} onNavigate={onNavigate}>{article.chapterName}</KnowledgeLink><span>/</span></>}<span aria-current="page">{title}</span></nav><button type="button" onClick={onSearch}><MagnifyingGlass size={18} />搜索知识库</button></div>
    <details className="kb-mobile-topics"><summary><BookOpenText size={18} />浏览知识库目录<List size={18} /></summary><Sidebar route={route} onNavigate={onNavigate} /></details>
    <div className="kb-workspace-grid"><Sidebar route={route} onNavigate={onNavigate} /><div className="kb-page" key={route.key}>
      {article ? <ArticlePage article={article} onNavigate={onNavigate} /> : chapter ? <ChapterPage chapter={chapter} onNavigate={onNavigate} /> : route.type === 'library' ? <LibraryPage onNavigate={onNavigate} /> : route.type === 'faq' ? <FaqPage onNavigate={onNavigate} /> : route.type === 'resources' ? <ResourcesPage onNavigate={onNavigate} highlight={route.highlight} /> : route.type === 'glossary' ? <GlossaryPage /> : <div className="kb-not-found"><PageIntro eyebrow="页面未找到" title="这条路径暂时没有对应内容。" description="可以回到全部指南，或搜索你想完成的任务。" /><KnowledgeLink target={{ type: 'library' }} onNavigate={onNavigate}>浏览运营指南<ArrowRight size={18} /></KnowledgeLink></div>}
    </div></div>
  </main>;
}
