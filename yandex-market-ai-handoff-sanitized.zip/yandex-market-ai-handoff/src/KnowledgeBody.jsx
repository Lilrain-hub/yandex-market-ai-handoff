import { withBase } from './site-path.js';
import { Fragment, useEffect, useRef, useState } from 'react';
import { ArrowsOut, X } from '@phosphor-icons/react';
import { safeHref } from './knowledge-utils.js';

export function InlineText({ text = '' }) {
  const chunks = String(text).split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]*\)|`[^`]+`)/g);
  return chunks.map((chunk, index) => {
    if (chunk.startsWith('**') && chunk.endsWith('**')) return <strong key={index}>{chunk.slice(2, -2)}</strong>;
    if (chunk.startsWith('`') && chunk.endsWith('`')) return <code key={index}>{chunk.slice(1, -1)}</code>;
    const match = chunk.match(/^\[([^\]]+)\]\(([^)]*)\)$/);
    if (match) {
      const href = safeHref(match[2]);
      return href ? <a key={index} href={href} target={href.startsWith('http') ? '_blank' : undefined} rel={href.startsWith('http') ? 'noopener noreferrer' : undefined}>{match[1].replace(/\\_/g, '_')}</a> : <Fragment key={index}>{match[1]}</Fragment>;
    }
    return <Fragment key={index}>{chunk.replace(/\\([_&])/g, '$1')}</Fragment>;
  });
}

function GuideImage({ block, onZoom }) {
  const [failed, setFailed] = useState(false);
  return <figure className="guide-figure">
    {failed ? <p className="guide-image-fallback">这张操作截图暂时未能加载。可以刷新页面后重试。</p> :
      <button type="button" className="guide-image-button" onClick={() => onZoom(block)} aria-label={`放大图片：${block.alt}`}>
        <img src={withBase(block.src)} alt={block.alt} width={block.width} height={block.height} loading="lazy" onError={() => setFailed(true)} />
        <span><ArrowsOut size={16} />点击放大</span>
      </button>}
    <figcaption>{block.alt}</figcaption>
  </figure>;
}

function ImageLightbox({ image, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const active = document.activeElement;
    const overflow = document.body.style.overflow;
    ref.current.showModal(); document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = overflow; active?.isConnected && active.focus({ preventScroll: true }); };
  }, []);
  return <dialog className="guide-lightbox" ref={ref} aria-label={image.alt} onCancel={event => { event.preventDefault(); onClose(); }}
    onClick={event => { if (event.target === ref.current) onClose(); }}>
    <div className="guide-lightbox-top"><span>{image.alt}</span><button type="button" onClick={onClose} aria-label="关闭放大图片"><X size={24} /></button></div>
    <img src={withBase(image.src)} width={image.width} height={image.height} alt={image.alt} />
  </dialog>;
}

export function KnowledgeBody({ blocks, compact = false }) {
  const [image, setImage] = useState(null);
  return <div className={`guide-prose${compact ? ' is-compact' : ''}`}>
    {blocks.map((block, index) => {
      if (block.type === 'heading') {
        const Heading = block.level === 3 ? 'h3' : 'h2';
        return <Heading id={compact ? undefined : block.id} key={index}>{block.text}</Heading>;
      }
      if (block.type === 'image') return <GuideImage key={index} block={block} onZoom={setImage} />;
      if (block.type === 'list') {
        const List = block.ordered ? 'ol' : 'ul';
        return <List key={index}>{block.items.map((item, i) => <li key={i}><InlineText text={item} /></li>)}</List>;
      }
      if (block.type === 'table') return <div key={index} className="guide-table-scroll" role="region" aria-label="文章数据表格，可横向滚动" tabIndex={0}>
        <table><thead><tr>{block.rows[0].map((cell, i) => <th key={i} scope="col"><InlineText text={cell} /></th>)}</tr></thead>
          <tbody>{block.rows.slice(1).map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}><InlineText text={cell} /></td>)}</tr>)}</tbody></table>
      </div>;
      return <p key={index}><InlineText text={block.text} /></p>;
    })}
    {image && <ImageLightbox image={image} onClose={() => setImage(null)} />}
  </div>;
}
