export const chapters = [
  { id:'start',name:'新卖家入门指南',short:'从资料准备，到店铺激活',description:'开始开店前，先了解准备事项和操作顺序。',topics:['平台介绍','入驻要求','店铺注册','入驻流程','Yandex邮箱注册'] },
  { id:'finance',name:'收款与财务',short:'账户、回款与账单',description:'按任务查找收款配置、回款和费用相关指南。',topics:['收款政策','连连国际收款配置','回款流程及账单界面','平台佣金','订单费用'] },
  { id:'product',name:'产品与上架',short:'准备商品，完成上架',description:'查找商品导入、上架和后台设置相关操作。',topics:['产品上架','店铺产品上架限额政策','卖家后台切换语言'] },
  { id:'shipping',name:'发货与物流',short:'模式、仓库与订单发货',description:'从模式选择到仓库配置，按任务查看物流指南。',topics:['发货模式概览','FBP半托管模式','FBS自发货模式','FBS及本土发货仓库设置'] },
  { id:'logistics',name:'物流设置',short:'后台配置与验证',description:'查找后台物流设置的操作顺序和排查方法。',topics:['自发货物流设置','物流配置验证与排查'] },
  { id:'returns',name:'退货退款政策',short:'了解规则，处理售后',description:'查看售后处理相关任务；具体规则以适用政策为准。',topics:['退货退款处理','退货物流与退款账单'] },
  { id:'marketing',name:'营销推广',short:'平台活动与广告工具',description:'查找平台活动报名和广告工具的操作入口。',topics:['广告促销活动','促销途径与推广工具'] },
  { id:'brand',name:'品牌授权',short:'准备证明，提交审核',description:'查找品牌证明材料与后台提交相关指南。',topics:['品牌授权材料与提交','查看品牌授权审核结果'] },
  { id:'support',name:'客服支持',short:'如何开 case 与跟进回复',description:'查找平台工单提交与查看回复的操作指南。',topics:['如何开case','查看工单回复'] },
  { id:'migration',name:'收款账户迁移',short:'卢布店铺至人民币店铺',description:'查找卢布店铺迁移至人民币店铺的连连收款教程。当前通道和适用条件仍需核实。',topics:['连连收款账户迁移教程'] },
  { id:'faq',name:'常见问题',short:'定位问题，找到相关操作',description:'从常见问题查找相关操作指南。',topics:['如何找到店铺ID','选择FBP后无法激活','导入商品后的价格同步'] },
  { id:'documents',name:'文档索引',short:'教程、文件与资料入口',description:'按用途集中查找文章和资料文件。',topics:['操作教程索引','常用资料与附件'] },
];
const custom = {
  '店铺注册': { keywords:'开店 注册 入驻 激活 账号',outline:['准备注册资料','完成注册、审核与签约','配置商品、仓库与店铺激活'] },
  '连连国际收款配置': {keywords:'连连 连连收款 国际收款 绑定 收款 账户 回款 财务',outline:['确认认证与资料准备','进入后台并填写绑定信息','检查账户绑定结果']},
  '产品上架': { keywords:'商品 商品上架 产品 导入 Ozon Wildberries 上架',outline:['准备商品资料与导入来源','完成商品信息和同步设置','检查上架结果'] },
  'FBS及本土发货仓库设置': {keywords:'仓库 设置 FBS 本土 发货 物流 库存',outline:['进入后台添加仓库','选择模式并关联库存','保存设置并检查配置结果']},
  '如何找到店铺ID': {keywords:'ID 编号 216 14 店铺',outline:['找到后台店铺信息入口','识别所需店铺编号','核对提交给支持人员的信息']},
  '选择FBP后无法激活': {keywords:'FBP FBS 激活 失败 仓库',outline:['检查当前发货模式','查看FBS模式与仓库配置','核对激活前准备事项']},
  '导入商品后的价格同步': {keywords:'导入 价格 同步 Ozon Wildberries 自动',outline:['确认商品导入来源','检查价格同步设置','核对商品更新结果']},
};
export const articles = chapters.flatMap(chapter => chapter.topics.map((title,index) => ({
  id:`${chapter.id}-${index}`,chapter:chapter.id,chapterName:chapter.name,title,description:chapter.description,
  keywords:`${chapter.name} ${chapter.short} ${custom[title]?.keywords || ''}`,
  featured:['店铺注册','连连国际收款配置','产品上架','FBS及本土发货仓库设置'].includes(title),
  outline:custom[title]?.outline || ['适用情形与操作前准备','分步操作与界面配图','完成标志与常见问题'],
})));
export const resources = [
  {name:'禁售类目查询表',format:'XLSX',purpose:'查阅禁售与限制类目'},
  {name:'跨境运费定价表',format:'工具',purpose:'查找物流费用与核算资料',href:'https://示例服务商-tool-hub.pages.dev/#/freight'},
  {name:'本土运费计算表',format:'XLSX',purpose:'辅助本土发货费用核算'},
  {name:'轻小件物流设置教程',format:'VIDEO',purpose:'观看后台设置操作'},
  {name:'Bestsellers 活动教程',format:'PDF',purpose:'查阅活动报名操作'},
  {name:'平台介绍与开店说明',format:'PDF',purpose:'了解平台与开店准备事项'},
];
export const questions = [
  {title:'如何找到店铺 ID？',context:'需要确认店铺编号时，可以从相关操作指南开始。',article:'faq-0'},
  {title:'选择 FBP 后无法激活，如何处理？',context:'查看发货模式与仓库配置相关的排查顺序。',article:'faq-1'},
  {title:'导入商品后，价格为什么自动变化？',context:'查看商品导入来源及价格同步设置相关的检查项。',article:'faq-2'},
];
