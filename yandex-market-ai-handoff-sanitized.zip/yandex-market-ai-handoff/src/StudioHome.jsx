import { withBase } from './site-path.js';
import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import {
  ArrowDown, ArrowRight, ArrowUp, ArrowUpRight, Files, Plus,
} from '@phosphor-icons/react';
import { resources, questions } from './knowledge-data.js';
import { SurfaceDialog } from './App.jsx';
import { useStudioMotion } from './useStudioMotion.js';
import { KnowledgeHeader } from './KnowledgeHeader.jsx';
import { MerchantJourney } from './MerchantJourney.jsx';
import { ConsultationFloat } from './ConsultationFloat.jsx';
import { ResourceEntry } from './ResourceEntry.jsx';
import { HeroVideo } from './HeroVideo.jsx';
import { HeroConsultation } from './HeroConsultation.jsx';
import './hero-refinement.css';
import { useKnowledgeNavigation } from './useKnowledgeNavigation.js';

const KnowledgePages = lazy(() => import('./KnowledgePages.jsx').then(module => ({ default: module.KnowledgePages })));
const KnowledgeSearch = lazy(() => import('./KnowledgeSearch.jsx').then(module => ({ default: module.KnowledgeSearch })));

const smooth = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
const goTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: smooth(), block: 'start' });
export function StudioHome() {
  const rootRef = useRef(null);
  const [panel, setPanel] = useState(null);
  const [query, setQuery] = useState('');
  const [navigationOpen, setNavigationOpen] = useState(false);
  const { route, navigate } = useKnowledgeNavigation();
  const isHome = route.type === 'home';
  const motion = useStudioMotion(rootRef);
  const openSearch = (term = '') => { setQuery(term); setPanel({ type: 'search' }); };
  const onNavigate = target => {
    if (target.type === 'announcement') { setPanel(target); return; }
    setPanel(null);
    navigate(target);
  };
  useEffect(() => { if (isHome) document.title = 'Yandex Market商家服务知识库'; }, [isHome]);
  return <div className="studio-root" ref={rootRef} onFocusCapture={motion.finish}>
    <a className="skip-link" href={isHome ? '#studio-search' : '#knowledge-reading'}>{isHome ? '跳到知识库搜索' : '跳到正文'}</a>
    <KnowledgeHeader onNavigate={onNavigate} onSearch={() => openSearch()} onExpandedChange={setNavigationOpen} />
    <div className="studio-page-content" inert={navigationOpen ? true : undefined}>
    <main className="studio-main" hidden={!isHome}>
      <section className="studio-hero hero-refined" id="home" aria-labelledby="studio-heading">
        <HeroVideo depth active={isHome && !navigationOpen && !panel} />
        <div className="studio-hero-content">
          <h1 id="studio-heading" data-intro><span className="studio-hero-brand">YandexMarket</span><span className="studio-hero-title">卖家百科</span></h1>
          <p className="hero-service-line" data-intro>从开店到经营，有问就有答。</p>
          <p className="studio-hero-description" data-intro>从入驻准备到店铺运营，系统了解 Yandex Market 平台规则与经营知识。通过清晰的操作指引与实用教程，帮助卖家快速上手，让跨境经营更简单、更高效。</p>
          <HeroConsultation onSearch={openSearch} />
        </div>
        <div className="studio-hero-footnote"><span>少一点摸索，多一点方向。</span><button type="button" onClick={() => goTo('start-guide')} aria-label="向下了解开店步骤"><ArrowDown size={21} /></button><span>一本写给商家的经营手册</span></div>
      </section>

      <MerchantJourney onNavigate={onNavigate} />

      <section className="studio-answers" id="studio-faq" aria-labelledby="answers-heading">
        <div className="studio-answers-inner">
          <div className="studio-answers-copy" data-reveal><p className="studio-section-label">03 / A LITTLE HELP</p><h2 id="answers-heading">小问题，<br />也值得好好解答。</h2><p>你遇到的困惑，<br />也许可以从这里找到思路。</p><button type="button" onClick={() => onNavigate({ type: 'faq' })}>浏览常见问题<ArrowUpRight size={18} /></button></div>
          <div className="studio-faq-list" data-reveal>{questions.slice(0, 3).map((question, index) => <details key={question.title} onToggle={motion.refresh}><summary><span className="faq-index">0{index + 1}</span><span>{question.title}</span><Plus className="faq-toggle" size={21} /></summary><div className="studio-faq-body"><p>{question.context}</p><button type="button" onClick={() => onNavigate({ type: 'article', id: question.article })}>查看相关指南<ArrowUpRight size={17} /></button></div></details>)}</div>
        </div>
      </section>

      <section className="studio-section studio-resources" aria-labelledby="resources-heading">
        <div className="studio-resource-copy" data-reveal><p className="studio-section-label">04 / TOOLS & REFERENCES</p><h2 id="resources-heading">常用资料，<br />放在顺手的地方。</h2><p>表格、说明、操作视频，按用途集中收录。<br />需要的时候，少找一会儿。</p><button className="studio-text-link" type="button" onClick={() => onNavigate({ type: 'resources' })}>浏览全部资料索引<ArrowRight size={21} /></button></div>
        <div className="studio-resource-list" data-reveal>{[resources[0], resources[1], resources[4]].map((resource, index) => <ResourceEntry resource={resource} key={resource.name} onPreview={() => onNavigate({ type: 'resources', highlight: resource.name })}><span className={`studio-file file-${index}`}><Files size={26} /><small>{resource.format}</small></span><span className="resource-name"><strong>{resource.name}</strong><small>{resource.purpose}</small></span><span className="studio-file-status">{resource.href ? '打开工具' : '待补充'}</span><ArrowUpRight size={19} /></ResourceEntry>)}<p>在线工具可直接打开，其他文件补齐后提供下载入口。</p></div>
      </section>

      <section className="studio-bottom-cta"><div><span className="studio-dot" /><p>每一个下一步，<br className="mobile-break" />都从这里开始。</p></div><button type="button" onClick={() => openSearch()}>找一份操作指南<ArrowUpRight size={21} /></button></section>
    </main>
    {!isHome && <Suspense fallback={<main className="kb-loading" role="status">正在打开指南…</main>}><KnowledgePages route={route} onNavigate={onNavigate} onSearch={() => openSearch()} /></Suspense>}
    <footer className="studio-footer"><div><div className="studio-footer-brand"><img src={withBase('/assets/brand/logo-for-sellers.png')} width="3302" height="670" alt="Market for sellers" /><span>商家服务知识库</span></div><p>为每一天的经营，提供一点清晰的方向。</p></div><div className="studio-footer-links"><button type="button" onClick={() => onNavigate({ type: 'library' })}>全部运营指南<ArrowUpRight size={15} /></button><a href={withBase('/?view=classic')}>查看上一版<ArrowUpRight size={15} /></a><button type="button" onClick={() => window.scrollTo({ top: 0, behavior: smooth() })}>返回顶部<ArrowUp size={16} /></button></div></footer>
    </div>
    <ConsultationFloat hidden={navigationOpen || Boolean(panel) || !isHome} onFaq={() => onNavigate({ type: 'faq' })} />
    {panel?.type === 'search' ? <Suspense fallback={<span className="kb-loading-search" role="status">正在打开搜索…</span>}><KnowledgeSearch query={query} setQuery={setQuery} onClose={() => setPanel(null)} onNavigate={onNavigate} /></Suspense> : <SurfaceDialog panel={panel} onClose={() => setPanel(null)} onPanel={setPanel} query={query} setQuery={setQuery} theme="studio-dialog" />}
  </div>;
}
