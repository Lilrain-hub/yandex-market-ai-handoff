// Vite supplies BASE_URL for a root Site or a GitHub Pages project subdirectory.
export const siteBase = import.meta.env?.BASE_URL || '/';

export function withBase(path, base = siteBase) {
  if (!path || !path.startsWith('/') || path.startsWith('//') || base === '/') return path;
  const prefix = base.replace(/\/$/, '');
  return path === prefix || path.startsWith(`${prefix}/`) || path.startsWith(`${prefix}?`)
    ? path : `${prefix}${path}`;
}

export function withoutBase(path, base = siteBase) {
  const prefix = base.replace(/\/$/, '');
  if (!prefix) return path;
  if (path === prefix || path === `${prefix}/`) return '/';
  return path.startsWith(`${prefix}/`) ? path.slice(prefix.length) : path;
}
