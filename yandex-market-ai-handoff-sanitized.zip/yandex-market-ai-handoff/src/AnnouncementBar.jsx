import { ArrowRight, X } from '@phosphor-icons/react';
import './announcement.css';

export function AnnouncementBar({ announcement, onMore, onDismiss }) {
  return <section className="announcement-bar" aria-label="重要公告">
    <p className="announcement-copy">
      <strong>{announcement.label}</strong><span aria-hidden="true">｜</span>
      {announcement.message}{' '}
      {announcement.href
        ? <a className="announcement-more" href={announcement.href}>{announcement.actionLabel}<ArrowRight size={14} aria-hidden="true" /></a>
        : <button className="announcement-more" type="button" onClick={onMore}>{announcement.actionLabel}<ArrowRight size={14} aria-hidden="true" /></button>}
    </p>
    <button className="announcement-dismiss" type="button" aria-label="关闭公告" onClick={onDismiss}><X size={18} aria-hidden="true" /></button>
  </section>;
}
