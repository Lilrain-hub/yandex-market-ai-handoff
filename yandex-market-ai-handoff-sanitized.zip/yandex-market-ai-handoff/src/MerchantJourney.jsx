import { withBase } from './site-path.js';
import { ArrowRight, ArrowUpRight, BookOpenText, Check, ClipboardText, GearSix, Storefront } from '@phosphor-icons/react';
import './merchant-journey.css';

const phases = [
  { title: '开店前须知', description: '先了解平台，确认开店前的准备事项。', Icon: BookOpenText, links: [
    { label: '了解 Yandex Market', target: { type: 'article', id: 'start-0' } },
    { label: '查看入驻要求', target: { type: 'article', id: 'start-1' } },
    { label: '了解费用与回款', target: { type: 'chapter', id: 'finance' } },
  ] },
  { title: '注册前准备', description: '理清申请顺序，整理需要的账户与资料。', Icon: ClipboardText, links: [
    { label: '了解入驻流程', target: { type: 'article', id: 'start-3' } },
    { label: '准备注册资料', target: { type: 'article', id: 'start-2' } },
    { label: '注册 Yandex 邮箱', target: { type: 'article', id: 'start-4' } },
  ] },
  { title: '注册与店铺配置', description: '查看注册操作，继续完成账户和仓库设置。', Icon: GearSix, links: [
    { label: '查看店铺注册指南', target: { type: 'article', id: 'start-2' } },
    { label: '配置连连收款账户', target: { type: 'article', id: 'finance-1' } },
    { label: '设置发货仓库', target: { type: 'article', id: 'shipping-3' } },
  ] },
  { title: '开始日常经营', description: '从商品上架开始，逐步了解发货与推广。', Icon: Storefront, links: [
    { label: '准备商品与上架', target: { type: 'article', id: 'product-0' } },
    { label: '了解订单发货', target: { type: 'chapter', id: 'shipping' } },
    { label: '了解活动与推广', target: { type: 'chapter', id: 'marketing' } },
  ] },
];

export function MerchantJourney({ onNavigate }) {
  return <div className="merchant-journey">
    <div className="journey-container">
      <section className="journey-intro" id="start-guide" aria-labelledby="journey-intro-heading">
        <div className="journey-cover" data-reveal>
          <img src={withBase('/assets/brand/merchant-guide-burgundy.png')} width="1448" height="1086" alt="酒红色商家指南手册与橙红色包裹" loading="lazy" />
          <span className="journey-cover-caption"><Check size={19} weight="bold" />了解开店准备</span>
        </div>
        <div className="journey-intro-copy" data-reveal>
          <span className="journey-eyebrow"><BookOpenText size={19} />新卖家入门指南</span>
          <h2 id="journey-intro-heading">开店之前，<br className="journey-heading-break" />先把准备做清楚。</h2>
          <div className="journey-intro-note">
            <p>从了解入驻要求、准备注册资料，到配置收款和发货方式，把开店前后的重要事项按顺序理清楚。</p>
            <ul>{['了解入驻条件与注册流程', '准备账户与收款配置', '熟悉商品上架与仓库设置'].map(label => <li key={label}><Check size={19} weight="bold" />{label}</li>)}</ul>
            <span>从你当前的阶段开始，查看对应的操作指南。</span>
          </div>
          <button className="journey-intro-link" type="button" onClick={() => onNavigate({ type: 'chapter', id: 'start' })}>了解开店准备<ArrowRight size={22} /></button>
        </div>
      </section>

      <section className="journey-process" id="getting-started-steps" aria-labelledby="journey-process-heading">
        <div className="journey-process-heading" data-reveal>
          <h2 id="journey-process-heading">4 个阶段，<span>理清开店步骤</span></h2>
          <p>先做好准备，再逐步完成注册与店铺配置。按当前阶段查看指南，开始每一天的经营。</p>
        </div>
        <ol className="journey-stages">{phases.map(({ title, description, Icon, links }, index) => <li key={title} data-reveal>
          <div className="journey-stage-marker" aria-hidden="true"><span><Icon size={22} /></span>{index < phases.length - 1 && <ArrowRight className="journey-stage-arrow" size={19} />}</div>
          <div className="journey-stage-card">
            <div className="journey-stage-heading"><span aria-hidden="true">{index + 1}</span><h3>{title}</h3></div>
            <p>{description}</p>
            <ul>{links.map(link => <li key={link.label}><button type="button" onClick={() => onNavigate(link.target)}><span>{link.label}</span><ArrowUpRight size={16} /></button></li>)}</ul>
          </div>
        </li>)}</ol>
        <div className="journey-process-action" data-reveal><button type="button" onClick={() => onNavigate({ type: 'chapter', id: 'start' })}><span>查看开店指南<ArrowRight size={22} /></span><small>从资料准备<br />到店铺激活</small></button></div>
      </section>
    </div>
  </div>;
}
