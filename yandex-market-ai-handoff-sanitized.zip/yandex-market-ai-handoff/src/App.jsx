import { withBase } from './site-path.js';
import { useEffect, useRef, useState } from 'react';
import { ArrowCounterClockwise, ArrowDown, ArrowRight, ArrowUpRight, List, MagnifyingGlass, X } from '@phosphor-icons/react';
import { chapters, articles, resources, questions } from './content.js';
import { ArtEntry } from './ArtEntry.jsx';
import { useHomepageMotion } from './motion.js';
import { ResourceEntry } from './ResourceEntry.jsx';

const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function SurfaceDialog({ panel, onClose, onPanel, query, setQuery, theme = '' }) {
  const ref = useRef(null);
  const inputRef = useRef(null);
  const titleRef = useRef(null);
  useEffect(() => {
    if (!panel) return;
    const dialog = ref.current;
    const returnFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    dialog.showModal();
    document.body.style.overflow = 'hidden';
    if (panel.type === 'search') inputRef.current?.focus();
    else titleRef.current?.focus();
    return () => {
      dialog.close();
      document.body.style.overflow = previousOverflow;
      requestAnimationFrame(() => {
        if (returnFocus?.isConnected && !document.querySelector('dialog[open]')) returnFocus.focus({ preventScroll: true });
      });
    };
  }, [!!panel]);
  useEffect(() => {
    if (!panel || !ref.current) return;
    ref.current.scrollTop = 0;
    if (panel.type === 'search') inputRef.current?.focus();
    else titleRef.current?.focus();
  }, [panel?.type, panel?.id]);
  if (!panel) return null;
  const chapter = panel.type === 'chapter' ? chapters.find(item => item.id === panel.id) : null;
  const article = panel.type === 'article' ? articles.find(item => item.id === panel.id) : null;
  const searchTerms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const matches = (searchTerms.length ? articles.filter(item => searchTerms.every(term => `${item.title} ${item.keywords} ${item.chapterName}`.toLowerCase().includes(term))) : articles.filter(item => item.featured)).slice(0, 12);
  const matchingResources = searchTerms.length ? resources.filter(item => searchTerms.every(term => `${item.name} ${item.purpose} ${item.format}`.toLowerCase().includes(term))) : [];
  const title = panel.type === 'announcement' ? '最新公告' : panel.type === 'search' ? '找一份操作指南' : chapter?.name || article?.title || (panel.type === 'resources' ? '文档索引' : panel.type === 'menu' ? '浏览知识库' : '常见问题');
  const openArticle = (id) => onPanel({ type: 'article', id });
  return <dialog ref={ref} className={`surface-dialog ${theme}`} aria-labelledby="surface-dialog-title"
    onCancel={(event) => { event.preventDefault(); onClose(); }}
    onClick={(event) => { if (event.target === ref.current) onClose(); }}>
    <div className="dialog-sheet">
      <div className="dialog-top"><span className="dialog-eyebrow">Yandex Market商家服务知识库</span><button type="button" className="icon-button close-dialog" onClick={onClose} aria-label="关闭"><X size={24} weight="bold" /></button></div>
      {article && <button className="back-link" type="button" onClick={() => onPanel({ type:'chapter', id:article.chapter })}>返回{article.chapterName}</button>}
      <h2 id="surface-dialog-title" ref={titleRef} tabIndex={-1}>{title}</h2>
      {panel.type === 'announcement' && <><span className="content-status">{panel.announcement.label}</span><p className="dialog-description" style={{ marginTop: 20 }}>{panel.announcement.message}</p><p className="plain-note">测试公告预览 · 正式详情链接待配置</p></>}
      {panel.type === 'search' && <>
        <form className="dialog-search" onSubmit={(event) => event.preventDefault()}><MagnifyingGlass size={22} /><input ref={inputRef} aria-label="搜索知识库" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="试试：店铺注册、连连、FBS" /><button type="button" className="clear-search" aria-label="清空搜索" onClick={() => setQuery('')} disabled={!query}><X size={17} /></button></form>
        <p className="result-label" role="status">{query.trim() ? `找到 ${matches.length + matchingResources.length} 个相关入口` : '常用操作指南'}</p>
        <div className="article-list">{matches.map(item => <button type="button" key={item.id} onClick={() => openArticle(item.id)}><span><small>{item.chapterName}</small><strong>{item.title}</strong></span><ArrowUpRight size={21} /></button>)}{matchingResources.map(item => <ResourceEntry resource={item} key={item.name} onPreview={() => onPanel({type:'resources',highlight:item.name})}><span><small>{item.href ? '在线工具 · 新窗口打开' : '资料文件 · 待补充'}</small><strong>{item.name}</strong></span><ArrowUpRight size={21} /></ResourceEntry>)}</div>
        {!matches.length && !matchingResources.length && <div className="empty-state"><MagnifyingGlass size={36} weight="light" /><h3>换一个关键词试试</h3><p>可以搜索「收款」「仓库」「上架」，或先查看新卖家入门指南。</p><button type="button" className="text-action" onClick={() => {
          if (theme === 'studio-dialog') onPanel({ type: 'chapter', id: 'start' });
          else { onClose(); document.getElementById('chapter-index')?.scrollIntoView({ behavior:reducedMotion()?'auto':'smooth' }); }
        }}>{theme === 'studio-dialog' ? '查看新卖家入门指南' : '浏览全部章节'}<ArrowRight size={18} /></button></div>}
      </>}
      {chapter && <><p className="dialog-description">{chapter.description}</p><div className="article-list">{articles.filter(item => item.chapter === chapter.id).map(item => <button type="button" key={item.id} onClick={() => openArticle(item.id)}><span><small>操作指南</small><strong>{item.title}</strong></span><ArrowUpRight size={21} /></button>)}</div></>}
      {article && <article className="article-preview"><span className="content-status">教程结构预览</span><p>{article.description}</p><ol>{article.outline.map((step,index) => <li key={step}><span>{String(index+1).padStart(2,'0')}</span><div><h3>{step}</h3></div></li>)}</ol><div className="article-note">这份教程的正文、操作截图和适用规则正在整理中。</div><button type="button" className="text-action" onClick={() => onPanel({ type:'chapter', id:article.chapter })}>查看相关指南<ArrowRight size={20} /></button></article>}
      {panel.type === 'resources' && <><p className="dialog-description">常用资料按用途集中查找。</p><div className="resource-list">{resources.map(item => <ResourceEntry resource={item} className={`resource-row${panel.highlight===item.name?' is-highlighted':''}`} key={item.name}><span className="file-format">{item.format}</span><div><h3>{item.name}</h3><p>{item.purpose}</p></div><span className="resource-status">{item.href ? <>打开工具 <ArrowUpRight size={15} /></> : '待补充'}</span></ResourceEntry>)}</div><p className="plain-note">在线工具可直接打开，其他资料文件补齐后提供对应版本和下载入口。</p></>}
      {panel.type === 'faq' && <><p className="dialog-description">从常见问题出发，找到对应的操作指南。</p><div className="faq-list">{questions.map(item => <details key={item.title}><summary>{item.title}<ArrowDown size={20} /></summary><p>{item.context}</p><button className="text-action" type="button" onClick={() => openArticle(item.article)}>查看相关指南<ArrowUpRight size={18} /></button></details>)}</div></>}
      {panel.type === 'menu' && <div className="article-list mobile-nav-list"><button type="button" onClick={() => {onClose();document.getElementById('chapter-index')?.scrollIntoView({behavior:reducedMotion()?'auto':'smooth'});}}><strong>运营指南</strong><ArrowUpRight size={21}/></button><button type="button" onClick={() => onPanel({type:'resources'})}><strong>文档索引</strong><ArrowUpRight size={21}/></button><button type="button" onClick={() => onPanel({type:'faq'})}><strong>常见问题</strong><ArrowUpRight size={21}/></button><button type="button" onClick={() => onPanel({type:'search'})}><strong>搜索知识库</strong><MagnifyingGlass size={21}/></button></div>}
    </div>
  </dialog>;
}

export function App() {
  const [panel, setPanel] = useState(null);
  const [query, setQuery] = useState('');
  const pageRef = useRef(null);
  const heroRef = useRef(null);
  const searchRef = useRef(null);
  const motion = useHomepageMotion(pageRef, heroRef, panel);
  const scrollToIndex = () => document.getElementById('chapter-index')?.scrollIntoView({ behavior:reducedMotion()?'auto':'smooth' });
  return <div ref={pageRef} className="page-root" onFocusCapture={motion.finish}>
    <a className="skip-link" href="#knowledge-search">跳到知识库搜索</a>
    <header className="site-header">
      <a className="wordmark" href="#home" aria-label="Yandex Market商家服务知识库首页" onClick={(event) => { event.preventDefault(); window.scrollTo({top:0,behavior:reducedMotion()?'auto':'smooth'}); }}>Yandex Market<span>商家服务知识库</span></a>
      <nav aria-label="主导航"><button type="button" onClick={scrollToIndex}>运营指南</button><button type="button" onClick={() => setPanel({ type:'resources' })}>文档索引</button><button type="button" onClick={() => setPanel({ type:'faq' })}>常见问题</button><button className="header-search" type="button" aria-label="搜索教程" onClick={() => { window.scrollTo({ top:0, behavior:reducedMotion()?'auto':'smooth' }); searchRef.current?.focus({ preventScroll:true }); }}><MagnifyingGlass size={29} weight="bold" /></button><button className="mobile-menu" type="button" aria-label="打开导航" onClick={() => setPanel({type:'menu'})}><List size={25} weight="bold" /></button></nav>
    </header>
    <main>
      <section ref={heroRef} className="hero" id="home" aria-label="商家服务知识库首页" onPointerMove={motion.move} onPointerLeave={motion.leave}>
        <div className="art-stage" aria-label="交互章节入口">
          <ArtEntry className="entry-start" name="新卖家入门" image={withBase('/assets/entry-start.png')} onOpen={() => setPanel({ type:'chapter',id:'start' })} />
          <ArtEntry className="entry-product" name="产品与上架" image={withBase('/assets/entry-product.png')} onOpen={() => setPanel({ type:'chapter',id:'product' })} />
          <ArtEntry className="entry-shipping" name="发货与物流" image={withBase('/assets/entry-shipping.png')} onOpen={() => setPanel({ type:'chapter',id:'shipping' })} />
          <div className="hand-parallax"><img className="hand-line" src={withBase('/assets/hand-line.png')} alt="" aria-hidden="true" draggable="false" /></div>
        </div>
        <div className="hero-copy">
          <h1><span>商家服务</span><span>知识库</span></h1>
          <p>开店、上架、发货，找到你的下一步。</p>
          <form className="hero-search" id="knowledge-search" role="search" onSubmit={(event) => { event.preventDefault(); setPanel({ type:'search' }); }}><input ref={searchRef} aria-label="搜索教程、问题或资料" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索教程、问题或资料" autoComplete="off" /><button type="submit" aria-label="搜索"><MagnifyingGlass size={34} weight="bold" /></button></form>
        </div>
        <div className="hero-bottom"><button type="button" className="browse-chapters" onClick={scrollToIndex}>浏览全部 12 个章节<ArrowRight size={24} weight="bold" /></button><button className="scroll-cue" type="button" aria-label="向下浏览章节" onClick={scrollToIndex}><ArrowDown size={30} /></button><button className="demo-caption replay-motion" type="button" onClick={motion.replay} aria-label="重播首页入场动效"><ArrowCounterClockwise size={15} />重播动效</button></div>
      </section>
      <section className="chapter-section" id="chapter-index" aria-labelledby="chapter-heading">
        <div className="section-heading"><div><span className="section-kicker">找到你的下一步</span><h2 id="chapter-heading">从一个问题开始。</h2></div><p>沿着任务找教程，<br />也可以按章节慢慢看。</p></div>
        <div className="chapter-grid">{chapters.map((chapter,index) => <button className="chapter-row" onFocus={motion.reveal} key={chapter.id} type="button" onClick={() => setPanel({ type:'chapter', id:chapter.id })}><span className="chapter-number">{String(index+1).padStart(2,'0')}</span><span><strong>{chapter.name}</strong><small>{chapter.short}</small></span><ArrowUpRight size={24} /></button>)}</div>
        <div className="chapter-footer"><span>Yandex Market商家服务知识库</span><div><button type="button" onClick={() => setPanel({ type:'resources' })}>文档与附件<ArrowUpRight size={17} /></button><button type="button" onClick={() => setPanel({ type:'faq' })}>常见问题<ArrowUpRight size={17} /></button></div></div>
      </section>
    </main>
    <SurfaceDialog panel={panel} onClose={() => setPanel(null)} onPanel={setPanel} query={query} setQuery={setQuery} />
  </div>;
}
