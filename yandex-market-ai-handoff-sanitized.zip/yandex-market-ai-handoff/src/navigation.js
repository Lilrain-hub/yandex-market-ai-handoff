// Navigation is a task-based view of the existing content, not a second content store.
const article = (title, description, id) => ({ title, description, target: { type: 'article', id } });
const chapter = (title, description, id) => ({ title, description, target: { type: 'chapter', id } });
const resource = (title, description, highlight) => ({ title, description, target: { type: 'resources', highlight } });

export const navigation = [
  {
    id: 'getting-started', label: '开店入门',
    groups: [
      { title: '开店准备', items: [
        article('了解平台与入驻要求', '先看条件，再准备开店资料', 'start-1'),
        article('准备店铺注册资料', '整理申请前需要的信息', 'start-2'),
        article('完成店铺注册', '按步骤查看注册与审核流程', 'start-2'),
        article('检查店铺激活事项', '确认商品、仓库和账户设置', 'start-5'),
      ] },
      { title: '账户与收款', items: [
        article('注册 Yandex 邮箱', '查看邮箱开通与验证步骤', 'start-4'),
        article('配置连连收款账户', '了解认证、绑定与结果检查', 'finance-1'),
        chapter('了解费用与回款', '查找费用说明与账单指南', 'finance'),
        article('查看品牌授权要求', '了解材料准备与提交方式', 'brand-0'),
      ] },
      { title: '开店后的第一步', items: [
        article('准备商品与上架', '从商品资料开始，完成发布', 'product-0'),
        article('选择发货模式', '了解 FBS 与 FBP 的操作区别', 'shipping-0'),
        article('设置发货仓库', '查看后台配置与库存关联', 'shipping-3'),
        article('处理常见激活问题', '按问题查找检查与处理步骤', 'faq-1'),
      ] },
    ],
    featured: { label: '入门指南', title: '新卖家开店指南', description: '从资料准备到店铺激活，把开店步骤看清楚。', target: { type: 'chapter', id: 'start' } },
  },
  {
    id: 'products-fulfillment', label: '商品与履约',
    groups: [
      { title: '商品上架', items: [
        article('导入与发布商品', '查找商品资料与导入操作', 'product-0'),
        article('了解上架限额', '查看商品额度相关说明', 'product-1'),
        article('切换后台语言', '找到语言设置的操作入口', 'product-2'),
        article('检查价格同步', '排查导入后价格自动变化', 'faq-2'),
      ] },
      { title: '发货与物流', items: [
        article('比较发货模式', '从备货和履约方式开始了解', 'shipping-0'),
        article('了解 FBP 模式', '查找入仓与发货相关指南', 'shipping-1'),
        article('了解 FBS 自发货', '查看接单与发货的操作顺序', 'shipping-2'),
        chapter('配置物流与仓库', '完成设置，检查配置结果', 'logistics'),
        article('Extra Small 轻小件设置', '单独设置轻小件仓库与商品', 'logistics-2'),
      ] },
      { title: '售后与排查', items: [
        article('处理退货退款', '查找适用规则与处理入口', 'returns-0'),
        article('查看退款账单', '了解退货物流与账单影响', 'returns-1'),
        article('验证物流配置', '检查设置与常见问题', 'logistics-1'),
        chapter('联系平台客服', '提交工单并跟进回复', 'support'),
      ] },
    ],
    featured: { label: '履约指南', title: '把发货步骤理清楚', description: '从选择发货模式，到配置仓库与处理订单。', target: { type: 'chapter', id: 'shipping' } },
  },
  {
    id: 'business-finance', label: '经营与收款',
    groups: [
      { title: '收款与账单', items: [
        article('了解收款政策', '查看回款相关条件与说明', 'finance-0'),
        article('绑定连连收款', '查找账户配置与绑定指南', 'finance-1'),
        article('查询回款与账单', '找到后台账单与回款入口', 'finance-2'),
        article('了解订单费用', '查找订单扣费相关说明', 'finance-4'),
      ] },
      { title: '营销与推广', items: [
        article('了解广告促销活动', '查找活动与广告操作指南', 'marketing-0'),
        article('选择推广工具', '按经营任务了解推广途径', 'marketing-1'),
        resource('查找活动资料', '查看活动教程的整理状态', 'Bestsellers 活动教程'),
      ] },
      { title: '账户与资质', items: [
        chapter('收款账户迁移', '查看迁移指南与适用说明', 'migration'),
        article('提交品牌授权', '了解证明材料与提交步骤', 'brand-0'),
        article('查看授权审核', '查找审核结果相关指南', 'brand-1'),
        article('找到店铺 ID', '核对后台的店铺编号', 'faq-0'),
      ] },
    ],
    featured: { label: '财务指南', title: '收款与账单，清楚查', description: '集中查找账户配置、回款与费用相关指南。', target: { type: 'chapter', id: 'finance' } },
  },
  {
    id: 'resources-support', label: '资料与支持',
    groups: [
      { title: '常用资料', items: [
        resource('禁售类目查询表', '查找禁售与限制类目资料', '禁售类目查询表'),
        resource('运费与核算资料', '查看跨境与本土运费资料', '跨境运费定价表'),
        resource('物流设置视频', '查看视频资料的整理状态', '轻小件物流设置教程'),
        resource('全部文档与附件', '按用途浏览资料索引'),
      ] },
      { title: '常见问题', items: [
        article('如何找到店铺 ID', '核对需要提供的店铺编号', 'faq-0'),
        article('FBP 店铺无法激活', '检查发货模式与仓库配置', 'faq-1'),
        article('导入后价格变化', '查找价格同步相关设置', 'faq-2'),
        { title: '浏览全部常见问题', description: '从具体问题找到相关操作', target: { type: 'faq' } },
      ] },
      { title: '获得帮助', items: [
        article('向平台提交工单', '查看开 case 的操作顺序', 'support-0'),
        article('跟进工单回复', '查找回复与后续处理指南', 'support-1'),
        chapter('浏览全部教程索引', '按章节查找对应的操作', 'documents'),
        { title: '术语速查', description: '查找 FBS、FBP 和后台常见名词', target: { type: 'glossary' } },
      ] },
    ],
    featured: { label: '资料索引', title: '常用资料，集中查找', description: '表格、说明与操作视频，按用途整理在一起。', target: { type: 'resources' } },
  },
];
