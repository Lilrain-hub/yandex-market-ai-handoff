import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { Pause, Play } from '@phosphor-icons/react';
import { withBase } from './site-path.js';
import './hero-video.css';

const mediaRoot = '/assets/brand/motion/';
const HeroRelief = lazy(() => import('./HeroRelief.jsx').catch(() => ({ default: () => null })));
const prefersStill = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches
  || Boolean(navigator.connection?.saveData);

export function HeroVideo({ active, depth = false }) {
  const containerRef = useRef(null);
  const videoRef = useRef(null);
  const [still, setStill] = useState(prefersStill);
  const stillRef = useRef(still);
  const [mobile, setMobile] = useState(() => window.matchMedia('(max-width: 650px)').matches);
  const [requested, setRequested] = useState(null);
  const [inView, setInView] = useState(true);
  const [visible, setVisible] = useState(() => !document.hidden);
  const [playing, setPlaying] = useState(false);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const wantsMotion = requested ?? !still;
  const [loaded, setLoaded] = useState(() => !prefersStill());
  const variant = mobile ? 'mobile' : 'desktop';
  const canPlay = active && inView && visible && wantsMotion && !failed;

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const compact = window.matchMedia('(max-width: 650px)');
    const connection = navigator.connection;
    const updatePreference = () => {
      const next = prefersStill();
      // Network quality updates must not undo a visitor's explicit Pause choice.
      if (next === stillRef.current) return;
      stillRef.current = next;
      setStill(next);
      setRequested(null);
    };
    const updateSize = () => setMobile(compact.matches);
    const updateVisibility = () => setVisible(!document.hidden);
    const container = containerRef.current;
    const header = container.closest('.studio-root')?.querySelector('.knowledge-header');
    let frame = 0;
    const measureViewport = () => {
      frame = 0;
      const box = container.getBoundingClientRect();
      const topInset = Math.ceil(header?.getBoundingClientRect().height || 0);
      setInView(box.bottom > topInset && box.top < window.innerHeight);
    };
    // One measurement per animation frame also accounts for the sticky header occlusion.
    const scheduleMeasure = () => { if (!frame) frame = requestAnimationFrame(measureViewport); };
    measureViewport();
    const headerObserver = new ResizeObserver(scheduleMeasure);
    if (header) headerObserver.observe(header);
    window.addEventListener('scroll', scheduleMeasure, { passive: true });
    window.addEventListener('resize', scheduleMeasure);
    reduced.addEventListener('change', updatePreference);
    compact.addEventListener('change', updateSize);
    connection?.addEventListener('change', updatePreference);
    document.addEventListener('visibilitychange', updateVisibility);
    return () => {
      headerObserver.disconnect();
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', scheduleMeasure);
      window.removeEventListener('resize', scheduleMeasure);
      reduced.removeEventListener('change', updatePreference);
      compact.removeEventListener('change', updateSize);
      connection?.removeEventListener('change', updatePreference);
      document.removeEventListener('visibilitychange', updateVisibility);
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let cancelled = false;
    if (canPlay) {
      video.muted = true;
      video.play()?.catch(() => {
        // Autoplay restrictions (including phone low-power mode) leave a usable play button.
        if (!cancelled) setPlaying(false);
      });
    } else video.pause();
    return () => { cancelled = true; video.pause(); };
  }, [canPlay, variant, attempt]);

  const toggle = () => {
    setRequested(!playing);
    if (!playing) { setLoaded(true); setAttempt(value => value + 1); }
  };

  return <>
    <div className="studio-hero-media" ref={containerRef} aria-hidden="true">
      <picture>
        <source media="(max-width: 650px)" srcSet={withBase(`${mediaRoot}hero-flow-mobile-v2-poster.jpg`)} />
        <img className="studio-hero-poster" src={withBase(`${mediaRoot}hero-flow-desktop-v2-poster.jpg`)}
          width="1600" height="900" alt="" fetchPriority="high" draggable="false" />
      </picture>
      {!failed && (loaded || wantsMotion) && <video key={variant} ref={videoRef}
        className={`studio-hero-video${ready ? ' is-ready' : ''}`}
        src={withBase(`${mediaRoot}hero-flow-${variant}-v2.mp4`)}
        poster={withBase(`${mediaRoot}hero-flow-${variant}-v2-poster.jpg`)}
        muted loop playsInline preload="none" disablePictureInPicture tabIndex={-1}
        onLoadStart={() => { setReady(false); setPlaying(false); }}
        onLoadedData={() => setReady(true)}
        onPlaying={() => { setReady(true); setPlaying(true); }}
        onPause={() => setPlaying(false)}
        onError={() => { setFailed(true); setPlaying(false); }} />}
      {depth && ready && !failed && !still && !mobile && videoRef.current && <Suspense fallback={null}>
        <HeroRelief key={variant} video={videoRef.current} running={canPlay && playing} />
      </Suspense>}
      <div className="studio-hero-shade" />
    </div>
    {!failed && <button className="studio-hero-playback" type="button" onClick={toggle}
      aria-label={playing ? '暂停背景动画' : '播放背景动画'} title={playing ? '暂停背景动画' : '播放背景动画'}>
      {playing ? <Pause size={17} weight="fill" aria-hidden="true" /> : <Play size={17} weight="fill" aria-hidden="true" />}
    </button>}
  </>;
}
