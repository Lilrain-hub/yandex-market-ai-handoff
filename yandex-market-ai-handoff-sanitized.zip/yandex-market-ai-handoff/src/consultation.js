// Add the supplied, original QR asset here when it is available.
// The layout reference's QR is not the site's consultation contact.
export const consultation = {
  qrImage: null,
  qrAlt: '商家顾问咨询二维码',
  title: '开店有疑问？',
};
