import { withBase } from './site-path.js';
// A small, deliberately limited Markdown model. Source text is never executed as HTML.
export const plainText = value => String(value || '').replace(/!\[[^\]]*\]\([^)]*\)/g, '')
  .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[\*#`|]/g, '').replace(/\\([_&])/g, '$1');
export const normalize = value => plainText(value).toLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
export const safeHref = value => {
  const href = String(value || '').replace(/\\([_&])/g, '$1');
  return /^(https?:\/\/|\/(?!\/)|#)/i.test(href) ? withBase(href) : null;
};

export function markdownBlocks(markdown, imageMap = {}) {
  const lines = String(markdown || '').trim().split('\n');
  const blocks = [];
  let headingIndex = 0;
  const heading = (text, level = 2) => blocks.push({ type: 'heading', text: plainText(text), level, id: `section-${headingIndex++}` });
  const isSpecial = line => /^(#{1,6} |!\[|\| |[-*] |\d+\. |第\s*\d+\s*步[：:])/.test(line) || /^\*\*[^*]+\*\*[：:]?$/.test(line);
  for (let i = 0; i < lines.length;) {
    const line = lines[i].trim();
    if (!line) { i++; continue; }
    if (/^#{1,6} /.test(line)) { heading(line.replace(/^#+ /, ''), 2); i++; continue; }
    if (/^第\s*\d+\s*步[：:]/.test(line)) { heading(line, 3); i++; continue; }
    if (/^\*\*[^*]+\*\*[：:]?$/.test(line)) { heading(line, /^\*\*步骤/.test(line) ? 3 : 2); i++; continue; }
    const image = line.match(/^!\[([^\]]*)\]\((.*?)\)$/);
    if (image) {
      const originalUrl = image[2].replace(/\\&/g, '&');
      const asset = imageMap[originalUrl];
      if (asset?.src) blocks.push({ type: 'image', ...asset, alt: image[1] || asset.alt });
      i++; continue;
    }
    if (line.startsWith('|')) {
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        const cells = lines[i++].trim().replace(/^\||\|$/g, '').split('|').map(cell => cell.trim());
        if (!cells.every(cell => /^:?-{2,}:?$/.test(cell))) rows.push(cells);
      }
      if (rows.length) blocks.push({ type: 'table', rows });
      continue;
    }
    if (/^[-*] |^\d+\. /.test(line)) {
      const ordered = /^\d+\. /.test(line);
      const items = [];
      while (i < lines.length && (ordered ? /^\d+\. / : /^[-*] /).test(lines[i].trim())) {
        items.push(lines[i++].trim().replace(ordered ? /^\d+\. / : /^[-*] /, ''));
      }
      blocks.push({ type: 'list', ordered, items }); continue;
    }
    const paragraph = [line]; i++;
    while (i < lines.length && lines[i].trim() && !isSpecial(lines[i].trim())) paragraph.push(lines[i++].trim());
    blocks.push({ type: 'paragraph', text: paragraph.join(' ') });
  }
  return blocks;
}

export const articlePath = id => `/guides/${encodeURIComponent(id)}`;
export const chapterPath = id => id === 'faq' ? '/questions' : id === 'documents' ? '/library' : `/topics/${encodeURIComponent(id)}`;
export function targetPath(target) {
  return withBase(rawTargetPath(target));
}
function rawTargetPath(target) {
  if (target.type === 'home') return '/';
  if (target.type === 'article') {
    if (target.id === 'documents-0') return '/library';
    if (target.id === 'documents-1') return '/resources';
    return articlePath(target.id);
  }
  if (target.type === 'chapter') return chapterPath(target.id);
  if (target.type === 'resources') return `/resources${target.highlight ? `?highlight=${encodeURIComponent(target.highlight)}` : ''}`;
  if (target.type === 'faq') return '/questions';
  if (target.type === 'glossary') return '/glossary';
  return '/library';
}

export function buildSearchIndex(articles, resources, glossary) {
  return [
    ...articles.filter(item => !item.redirect).map(item => ({
      id: item.id, type: item.kind === 'question' ? 'question' : 'guide', title: item.title,
      description: item.description, label: item.chapterName, status: item.status,
      target: { type: 'article', id: item.id },
      haystack: normalize(`${item.title} ${item.chapterName} ${item.description} ${item.keywords} ${item.markdown} ${(item.blocks || []).filter(block => block.type === 'image').map(block => block.alt).join(' ')}`),
    })),
    ...resources.map((item, index) => ({ id: `resource-${index}`, type: 'resource', title: item.name,
      description: item.purpose, label: item.format, href: item.href,
      target: { type: 'resources', highlight: item.name }, haystack: normalize(`${item.name} ${item.purpose} ${item.format} ${item.keywords || ''}`) })),
    ...glossary.map((item, index) => ({ id: `term-${index}`, type: 'term', title: item.term,
      description: item.description, label: '术语速查', target: { type: 'glossary' },
      haystack: normalize(`${item.term} ${item.description}`) })),
  ];
}

export function searchIndex(index, query, kind = 'all') {
  const raw = String(query || '').trim();
  const terms = raw.split(/\s+/).map(normalize).filter(Boolean);
  if (!terms.length) return [];
  return index.filter(item => (kind === 'all' || kind === item.type) && terms.every(term => item.haystack.includes(term)))
    .map(item => ({ ...item, score: normalize(item.title) === normalize(raw) ? 100 :
      normalize(item.title).includes(normalize(raw)) ? 60 : normalize(item.description).includes(normalize(raw)) ? 30 : 10 }))
    .sort((a, b) => b.score - a.score);
}
