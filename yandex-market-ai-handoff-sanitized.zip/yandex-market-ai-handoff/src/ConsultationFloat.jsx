import { withBase } from './site-path.js';
import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ChatCircleDots, X } from '@phosphor-icons/react';
import { consultation } from './consultation.js';
import './consultation-float.css';

export function ConsultationFloat({ hidden = false, onFaq }) {
  const [expanded, setExpanded] = useState(() => window.matchMedia('(min-width: 1101px)').matches);
  const [failedImage, setFailedImage] = useState(null);
  const launcherRef = useRef(null);
  const cardRef = useRef(null);
  const qrReady = Boolean(consultation.qrImage && failedImage !== consultation.qrImage);

  useEffect(() => {
    const desktop = window.matchMedia('(min-width: 1101px)');
    const update = event => setExpanded(event.matches);
    desktop.addEventListener('change', update);
    return () => desktop.removeEventListener('change', update);
  }, []);

  const collapse = () => {
    setExpanded(false);
    requestAnimationFrame(() => launcherRef.current?.focus({ preventScroll: true }));
  };
  const expand = () => {
    setExpanded(true);
    requestAnimationFrame(() => cardRef.current?.focus({ preventScroll: true }));
  };

  return <aside className="consultation-float" aria-label="商家咨询" hidden={hidden}
    onKeyDown={event => {
      if (expanded && event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); collapse(); }
    }}>
    <button className="consultation-launcher" ref={launcherRef} type="button" hidden={expanded}
      aria-expanded={expanded} aria-controls="consultation-card" onClick={expand}>
      <ChatCircleDots size={27} weight="regular" /><span>咨询</span>
    </button>
    <div className="consultation-card" id="consultation-card" ref={cardRef} tabIndex={-1} hidden={!expanded}
      role="region" aria-labelledby="consultation-heading">
      <button type="button" className="consultation-close" onClick={collapse} aria-label="收起咨询浮窗"><X size={17} /></button>
      <div className="consultation-surface">
        <div className="consultation-heading"><strong id="consultation-heading">{consultation.title}</strong><span>{qrReady ? '扫码咨询商家顾问' : '联系商家顾问'}</span></div>
        <div className="consultation-body">
          {qrReady ? <><img className="consultation-qr" src={withBase(consultation.qrImage)} alt={consultation.qrAlt} onError={() => setFailedImage(consultation.qrImage)} /><p className="consultation-scan-hint">请使用微信扫一扫</p></> : <>
            <div className="consultation-pending"><ChatCircleDots size={43} weight="light" aria-hidden="true" /><p>咨询二维码<span>待补充</span></p></div>
            <button className="consultation-faq" type="button" onClick={onFaq}>先看常见问题<ArrowUpRight size={15} /></button>
          </>}
        </div>
      </div>
    </div>
  </aside>;
}
