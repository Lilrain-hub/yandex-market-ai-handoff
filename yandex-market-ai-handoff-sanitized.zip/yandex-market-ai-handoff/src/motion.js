import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(useGSAP, ScrollTrigger);
export { gsap, useGSAP };

export function useHomepageMotion(root, hero, panel) {
  const pointer = useRef(null);
  const intro = useRef(null);
  const reveals = useRef(new Map());
  const played = useRef(false);

  useGSAP(() => {
    const media = gsap.matchMedia();
    media.add({
      reduced: '(prefers-reduced-motion: reduce)',
      fine: '(hover: hover) and (pointer: fine)',
      active: '(prefers-reduced-motion: no-preference)',
    }, ({ conditions }) => {
      if (conditions.reduced) return;
      const select = gsap.utils.selector(root);
      const entries = select('.art-entry');
      const sequence = gsap.timeline({ paused: true, defaults: { ease: 'power3.out' }, onComplete: () => { played.current = true; } });
      entries.forEach((entry, index) => sequence.from(entry, {
        x: [-80, 70, 80][index], y: [-35, -45, 45][index],
        rotation: [-5, 5, 6][index], scale: .94, opacity: 0,
        duration: 1.05, clearProps: 'transform,opacity',
      }, index * .1));
      sequence.from(select('.hero-copy h1 span'), { y: 40, opacity: 0, duration: .8, stagger: .09, clearProps: 'transform,opacity' }, .16)
        .from(select('.hero-copy p'), { y: 18, opacity: 0, duration: .65, clearProps: 'transform,opacity' }, .36)
        .from(select('.hero-search'), { y: 20, opacity: 0, duration: .65, clearProps: 'transform,opacity' }, .47)
        .from(select('.hand-line'), { opacity: 0, duration: .75, clearProps: 'opacity' }, .3)
        .from(select('.hero-bottom'), { opacity: 0, duration: .5, clearProps: 'opacity' }, .57);
      intro.current = sequence;
      if (played.current) sequence.progress(1);
      else sequence.play();

      if (conditions.fine) {
        const followers = [...entries.map(entry => ({
          target: entry.querySelector('.art-parallax'),
          depth: parseFloat(getComputedStyle(entry).getPropertyValue('--parallax')) || 20,
        })), { target: select('.hand-parallax')[0], depth: -5 }].map(({ target, depth }) => ({
          depth, x: gsap.quickTo(target, 'x', { duration: .7, ease: 'power3.out' }),
          y: gsap.quickTo(target, 'y', { duration: .7, ease: 'power3.out' }),
        }));
        pointer.current = (x, y) => followers.forEach(follower => {
          follower.x(x * follower.depth); follower.y(y * follower.depth * .65);
        });
      }

      // Opacity keeps the native chapter buttons in the keyboard flow.
      select('.chapter-row').forEach(row => reveals.current.set(row, gsap.from(row, {
        y: 22, opacity: .2, duration: .6, ease: 'power2.out',
        clearProps: 'transform,opacity',
        scrollTrigger: { trigger: row, start: 'top 94%', once: true },
      })));
      const onFontsLoaded = () => ScrollTrigger.refresh();
      document.fonts.addEventListener('loadingdone', onFontsLoaded);
      return () => {
        document.fonts.removeEventListener('loadingdone', onFontsLoaded);
        pointer.current = null; intro.current = null; reveals.current.clear();
      };
    });
    return () => media.revert();
  }, { scope: root });

  useEffect(() => { if (panel) pointer.current?.(0, 0); }, [panel]);

  return {
    move(event) {
      if (event.pointerType !== 'mouse' || !pointer.current) return;
      const box = hero.current.getBoundingClientRect();
      pointer.current((event.clientX - box.left) / box.width * 2 - 1, (event.clientY - box.top) / box.height * 2 - 1);
    },
    leave() { pointer.current?.(0, 0); },
    finish() { intro.current?.progress(1); },
    replay() { pointer.current?.(0, 0); intro.current?.restart(); },
    reveal(event) { reveals.current.get(event.currentTarget)?.progress(1); },
  };
}
