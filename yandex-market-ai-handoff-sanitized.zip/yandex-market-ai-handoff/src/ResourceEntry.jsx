export function ResourceEntry({ resource, className, onPreview, children }) {
  if (resource.href) return <a className={className} href={resource.href} target="_blank" rel="noopener noreferrer">{children}</a>;
  if (onPreview) return <button type="button" className={className} onClick={onPreview}>{children}</button>;
  return <div className={className}>{children}</div>;
}
