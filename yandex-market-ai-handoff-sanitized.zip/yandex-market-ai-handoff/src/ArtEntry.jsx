import { useRef } from 'react';
import { gsap, useGSAP } from './motion.js';

export function ArtEntry({ name, image, className, onOpen }) {
  const root = useRef(null);
  const controls = useRef(null);
  const drag = useRef(null);
  const suppressUntil = useRef(0);
  const pointerId = useRef(null);
  const { contextSafe } = useGSAP(() => {
    const media = gsap.matchMedia();
    media.add('(prefers-reduced-motion: no-preference)', () => {
      const dragged = root.current.querySelector('.art-drag');
      const tilted = root.current.querySelector('.art-tilt');
      const quick = (target, property, duration = .35) => gsap.quickTo(target, property, { duration, ease: 'power3.out' });
      const x = quick(dragged, 'x', .12), y = quick(dragged, 'y', .12);
      const rotateX = quick(tilted, 'rotationX'), rotateY = quick(tilted, 'rotationY');
      const lift = quick(tilted, 'y'), scaleX = quick(tilted, 'scaleX'), scaleY = quick(tilted, 'scaleY');
      let returning;
      controls.current = {
        start() { returning?.kill(); },
        tilt(x, y) { rotateX(-y * 5); rotateY(x * 6); },
        hover(active) { lift(active ? -9 : 0); scaleX(active ? 1.015 : 1); scaleY(active ? 1.015 : 1); if (!active) { rotateX(0); rotateY(0); } },
        drag(dx, dy) {
          x(Math.max(-58, Math.min(58, dx * .55)), gsap.getProperty(dragged, 'x'));
          y(Math.max(-32, Math.min(32, dy * .35)), gsap.getProperty(dragged, 'y'));
        },
        settle() {
          x.tween.pause(); y.tween.pause(); returning?.kill();
          returning = gsap.to(dragged, { x: 0, y: 0, duration: 1.05, ease: 'elastic.out(1,0.42)', overwrite: 'auto' });
        },
      };
      return () => {
        returning?.kill(); controls.current = null; drag.current = null;
        const button = root.current?.querySelector('.art-hit');
        if (button?.hasPointerCapture(pointerId.current)) button.releasePointerCapture(pointerId.current);
        root.current?.classList.remove('is-dragging');
      };
    });
    return () => media.revert();
  }, { scope: root });
  const settle = contextSafe((event) => {
    if (!drag.current) return;
    if (drag.current.moved) suppressUntil.current = performance.now() + 360;
    drag.current = null;
    root.current.classList.remove('is-dragging');
    controls.current?.settle();
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    pointerId.current = null;
  });
  return <div ref={root} className={`art-entry ${className}`}>
    <div className="art-parallax"><div className="art-drag"><div className="art-tilt">
      <img src={image} alt="" draggable="false" fetchPriority="high" />
      <button type="button" className="art-hit" aria-label={`浏览${name}`}
        onPointerEnter={event => { if (event.pointerType === 'mouse') controls.current?.hover(true); }}
        onPointerDown={event => {
          if (event.button !== 0 || !controls.current) return;
          controls.current.start();
          drag.current = { x: event.clientX, y: event.clientY, moved: false };
          pointerId.current = event.pointerId;
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={event => {
          if (!controls.current) return;
          const box = root.current.getBoundingClientRect();
          if (event.pointerType === 'mouse') controls.current.tilt((event.clientX-box.left)/box.width-.5, (event.clientY-box.top)/box.height-.5);
          if (!drag.current) return;
          const dx = event.clientX - drag.current.x, dy = event.clientY - drag.current.y;
          if (Math.abs(dx)>8 && Math.abs(dx)>Math.abs(dy)) drag.current.moved = true;
          if (drag.current.moved) { root.current.classList.add('is-dragging'); controls.current.drag(dx,dy); }
        }} onPointerUp={settle} onPointerCancel={settle} onLostPointerCapture={settle}
        onPointerLeave={() => { if (!drag.current) controls.current?.hover(false); }}
        onClick={event => { if (event.detail===0 || performance.now()>suppressUntil.current) onOpen(); }} />
    </div></div></div>
  </div>;
}
