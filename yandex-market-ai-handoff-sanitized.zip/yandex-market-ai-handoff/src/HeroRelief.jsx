import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

// The original flowing-red video is the material itself. A continuous, edge-cropped
// surface introduces shallow folds and lighting; there is no freestanding object.
export default function HeroRelief({ video, running }) {
  const host = useRef(null);
  const playback = useRef(running);
  const sync = useRef(null);
  playback.current = running;
  useEffect(() => { sync.current?.(); }, [running]);
  useEffect(() => {
    if (!video) return;
    const element = host.current;
    let renderer, geometry, material, texture, observer, clean, room, pmrem, environment;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, powerPreference: 'low-power' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.25));
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1;
      const scene = new THREE.Scene();
      room = new RoomEnvironment();
      pmrem = new THREE.PMREMGenerator(renderer);
      environment = pmrem.fromScene(room, .04);
      scene.environment = environment.texture;
      const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, .1, 20);
      camera.position.z = 6;
      texture = new THREE.VideoTexture(video);
      texture.colorSpace = THREE.SRGBColorSpace;
      geometry = new THREE.PlaneGeometry(2, 2, 96, 60);
      const initial = geometry.attributes.position.array.slice();
      const initialUv = geometry.attributes.uv.array.slice();
      material = new THREE.MeshPhysicalMaterial({ map: texture, color: '#fff3e8', roughness: .4,
        metalness: .1, clearcoat: .15, clearcoatRoughness: .35, envMapIntensity: .08,
        specularColor: '#cf5c3c', specularIntensity: .4 });
      const surface = new THREE.Mesh(geometry, material);
      scene.add(surface);
      scene.add(new THREE.AmbientLight('#fff4f0', 1.65));
      const light = new THREE.DirectionalLight('#ffbb8e', 2.8);
      light.position.set(-2, 3, 2.4); scene.add(light);
      element.appendChild(renderer.domElement);
      let frame = 0, inView = true, lost = false, elapsed = 0, last = 0, lastDraw = 0;
      let pointerX = 0, pointerY = 0, easedX = 0, easedY = 0;
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
      const fine = window.matchMedia('(hover: hover) and (pointer: fine)');
      const hero = element.closest('.studio-hero');
      const render = () => {
        if (lost || video.readyState < 2) return;
        renderer.render(scene, camera);
        element.classList.add('is-ready');
      };
      const resize = () => {
        if (lost) return;
        const box = element.getBoundingClientRect();
        if (!box.width || !box.height) return;
        const aspect = box.width / box.height;
        const videoAspect = (video.videoWidth || 1600) / (video.videoHeight || 900);
        renderer.setSize(box.width, box.height, false);
        camera.left = -aspect; camera.right = aspect; camera.updateProjectionMatrix();
        const positions = geometry.attributes.position, uv = geometry.attributes.uv;
        for (let i = 0; i < positions.count; i++) {
          const x = initial[i * 3], y = initial[i * 3 + 1];
          const edge = Math.pow(Math.abs(x), 1.7);
          const fold = Math.sin(x * 3.4 + y * 1.8 - .6) * .42 + Math.sin(x * 6.2 - y * 2.3) * .15;
          positions.setXYZ(i, x * aspect * 1.08, y * 1.08, fold * (.12 + edge * .88));
          uv.setXY(i, .5 + (initialUv[i * 2] - .5) * Math.min(1, aspect / videoAspect),
            .5 + (initialUv[i * 2 + 1] - .5) * Math.min(1, videoAspect / aspect));
        }
        positions.needsUpdate = true; uv.needsUpdate = true; geometry.computeVertexNormals();
        render();
      };
      const allowed = () => playback.current && inView && !document.hidden && !reduced.matches && !navigator.connection?.saveData && !lost;
      const animate = time => {
        frame = 0;
        if (!allowed()) return;
        elapsed += last ? Math.min(64, time - last) / 1000 : 0; last = time;
        if (time - lastDraw >= 40) {
          easedX += (pointerX - easedX) * .055; easedY += (pointerY - easedY) * .055;
          light.position.x = -2 + Math.sin(elapsed * .12) * .35 + easedX * .5;
          light.position.y = 3 + easedY * .25;
          surface.rotation.y = Math.sin(elapsed * .1) * .009 + easedX * .007;
          surface.rotation.x = easedY * .005;
          render(); lastDraw = time;
        }
        frame = requestAnimationFrame(animate);
      };
      const update = () => {
        cancelAnimationFrame(frame); frame = 0; last = 0;
        element.dataset.motion = allowed() ? 'running' : 'still';
        render();
        if (allowed()) frame = requestAnimationFrame(animate);
      };
      const move = event => {
        if (!fine.matches || event.pointerType !== 'mouse' || !allowed()) return;
        const box = hero.getBoundingClientRect();
        pointerX = Math.max(-1, Math.min(1, (event.clientX - box.left) / box.width * 2 - 1));
        pointerY = Math.max(-1, Math.min(1, (event.clientY - box.top) / box.height * 2 - 1));
      };
      const leave = () => { pointerX = 0; pointerY = 0; };
      const lostContext = event => { event.preventDefault(); lost = true; element.classList.remove('is-ready'); update(); };
      const visibility = new IntersectionObserver(entries => { inView = entries[0].isIntersecting; update(); });
      visibility.observe(element);
      observer = new ResizeObserver(resize); observer.observe(element);
      document.addEventListener('visibilitychange', update);
      reduced.addEventListener('change', update);
      hero.addEventListener('pointermove', move); hero.addEventListener('pointerleave', leave);
      renderer.domElement.addEventListener('webglcontextlost', lostContext);
      clean = () => {
        sync.current = null; cancelAnimationFrame(frame); visibility.disconnect();
        document.removeEventListener('visibilitychange', update); reduced.removeEventListener('change', update);
        hero.removeEventListener('pointermove', move); hero.removeEventListener('pointerleave', leave);
        renderer.domElement.removeEventListener('webglcontextlost', lostContext);
      };
      sync.current = update; resize(); update();
    } catch {
      element.classList.remove('is-ready');
    }
    return () => {
      clean?.(); observer?.disconnect(); texture?.dispose(); geometry?.dispose(); material?.dispose();
      environment?.dispose(); room?.dispose(); pmrem?.dispose();
      renderer?.dispose(); renderer?.domElement.remove();
    };
  }, [video]);
  return <div className="studio-hero-relief" ref={host} aria-hidden="true" />;
}
