import { sellerSource } from './seller-source.js';
import { articles as legacyArticles, chapters as legacyChapters, resources as legacyResources } from './content.js';
import { buildSearchIndex, markdownBlocks, plainText } from './knowledge-utils.js';

export const categories = [
  { id: 'getting-started', name: '开店入门', description: '准备资料，注册账户，完成店铺配置。', chapters: ['start', 'brand', 'migration'] },
  { id: 'products-fulfillment', name: '商品与履约', description: '从商品上架，到仓库、物流和售后。', chapters: ['product', 'shipping', 'logistics', 'returns'] },
  { id: 'business-finance', name: '经营与收款', description: '查看收款、账单与营销推广相关说明。', chapters: ['finance', 'marketing'] },
  { id: 'resources-support', name: '资料与支持', description: '查找问题、常用资料和平台支持入口。', chapters: ['support', 'faq', 'documents'] },
];
const section = key => sellerSource.sections[key]?.markdown || '';
const between = (text, first, last) => (text.split(first)[1] || '').split(last)[0].trim();
const registration = between(section('1.6'), '### **一、注册店铺**', '### **二、设置 FBS 仓库**');
const warehouse = between(section('1.6'), '### **二、设置 FBS 仓库**', '### **三、选择 示例服务商-LIANLIAN 作为支付伙伴**');
const partner = (section('1.6').split('### **三、选择 示例服务商-LIANLIAN 作为支付伙伴**')[1] || '').trim();
const clean = value => value.split('\n').filter(line => !line.includes('📷 图位') && !line.includes('扫描下方') &&
  !line.includes('二维码添加') && !/^\s*- 在线试算/.test(line)).join('\n').replace(/【待定[^】]*】/g, '').trim();
const sources = {
  'start-0': '1.1', 'start-1': '1.2', 'start-2': '1.6', 'start-3': '1.5', 'start-4': '1.7',
  'finance-0': '2.1', 'finance-1': '2.2', 'finance-2': '2.3', 'finance-3': '2.4', 'finance-4': '2.7 / 2.8 / 2.9',
  'product-0': '3.1', 'product-1': '3.2', 'product-2': '3.4',
  'shipping-0': '4.1', 'shipping-1': '4.2', 'shipping-2': '4.3', 'shipping-3': '1.6',
  'logistics-0': '5.2', 'logistics-1': 'FAQ 4 / 5', 'returns-0': 'returns', 'returns-1': '第六章 / 2.3',
  'marketing-0': '7.1', 'marketing-1': '7.1', 'brand-0': '3.3', 'brand-1': '3.3',
  'support-0': 'support', 'support-1': 'support', 'migration-0': 'FAQ 10',
};
const metadata = {
  'start-0': { title: '了解 Yandex Market 与卖家后台', description: '找到商城、卖家后台和平台中文教程入口。',
    markdown: 'Yandex Market 的商城、卖家后台与中文教程分别对应不同使用场景。\n\n' + section('1.1').split('\n\n').slice(1).join('\n\n'), related: ['start-1', 'start-3'] },
  'start-2': { title: '店铺注册：从 Yandex ID 到卖家后台', description: '跟随十步界面截图，完成账号创建、主体信息填写和店铺注册。', markdown: registration,
    before: ['准备可接收验证信息的手机号和邮箱。', '准备公司信息、营业执照及法人身份证。'],
    complete: '收到注册确认邮件，并能进入卖家后台查看店铺待办事项。', related: ['start-5', 'shipping-3', 'faq-0'] },
  'start-1': { description: '申请前，了解经营主体、营业执照和收款相关要求。' },
  'start-3': { description: '先理清申请顺序，再按当前阶段查看对应操作。' },
  'start-4': { title: 'Yandex 邮箱注册入口', description: '找到邮箱注册入口，继续完成 Yandex 账户准备。' },
  'finance-0': { title: '回款计划与付款说明', description: '了解资料中收录的付款计划、账单周期与查询入口。' },
  'finance-1': { title: '收款资料与 示例服务商-LIANLIAN 配置', description: '整理店铺和主体资料，了解选择支付伙伴后的对接流程。',
    markdown: '## 准备收款对接资料\n\n' + section('2.2').split('**注意事项**')[0] + '\n\n## 选择支付伙伴与签约\n\n' + partner,
    related: ['faq-0', 'finance-2'] },
  'finance-2': { title: '查询回款与付款状态', description: '找到财务页面，区分等待付款、已发送、已转账和未送达。', related: ['faq-10', 'support-0'] },
  'finance-4': { title: '订单费用与回款核算', description: '集中整理费用项目、计算基数与账单示例。', keywords: '费用 计算 定价 利润 回款额 试算', related: ['finance-3', 'finance-2', 'finance-6'] },
  'finance-3': { title: '平台佣金与类目费率查询', description: '按发货模式找到佣金参考表和类目查询工具。' },
  'product-1': { title: '商品上架限额与提额说明', description: '整理额度查看、变化条件和提额相关说明。' },
  'product-2': { title: '将卖家后台切换为中文', description: '通过右上角头像菜单找到语言设置。' },
  'product-0': { title: '从 Ozon / Wildberries 导入商品', description: '找到迁移入口，填写连接信息，并检查价格同步设置。',
    markdown: section('3.1').split('\n').filter(line => !line.includes('新店铺上架限额为')).join('\n'),
    before: ['准备源平台的 Client ID 与 API 密钥。', '先确认是否需要同步源平台价格。'],
    complete: '商品已导入目录，并已检查价格同步选项。', related: ['faq-2', 'product-1', 'brand-0'] },
  'shipping-0': { title: '比较 FBS、FBP 与本土发货', description: '从备货位置、履约方式和卖家阶段，了解三种发货模式。', related: ['shipping-1', 'shipping-2', 'shipping-4'] },
  'shipping-1': { title: 'FBP 半托管：备货与入仓流程', description: '查看供货创建、商品标签、外箱与交接单的准备顺序。' },
  'shipping-2': { title: 'FBS 自发货与 示例服务商 物流渠道', description: '了解物流渠道、开户交仓、问题件与轨迹查询。', resource: '包裹轨迹查询' },
  'shipping-3': { title: '添加 FBS 仓库并配置库存', description: '跟随五步界面截图，填写仓库、选择揽收点并设置发货计划。', markdown: warehouse,
    before: ['准备仓库地址、联系人和联系电话。', '确认实际发货节奏与可选择的揽收点。'],
    complete: '仓库、配送点位与发货计划已保存，并已为商品添加库存。', related: ['logistics-0', 'logistics-2', 'faq-1'] },
  'logistics-0': { title: '选择物流商与配置发货计划', description: '在仓库设置中选择配送方式、物流商点位与供货时间。', markdown: section('5.2').split('**Extra Small')[0], related: ['logistics-2', 'logistics-1'] },
  'logistics-1': { title: '物流配置报错：从哪里开始检查', description: '从无法运送、商品被隐藏和仓库模式相关问题开始定位。',
    markdown: '## 先确定报错属于哪一种\n\n- 提示“无法运送至所选地点”：检查运输方式、商品尺寸与类目。\n- 商品在轻小件仓库中被隐藏：检查仓库渠道是否与商品相匹配。\n- 店铺无法激活：检查是否已配置 FBS 仓库并为商品添加库存。\n\n## 继续查看对应问题\n\n下方相关指南中分别提供了排查说明和后台操作入口。', related: ['faq-3', 'faq-4', 'faq-1'] },
  'returns-1': { title: '退款与账单查询', description: '售后涉及款项变化时，查看财务记录与平台支持入口。',
    markdown: '## 查看相关财务记录\n\n退款会影响订单相关款项。可从卖家后台「财务 → 付款」查询状态，并结合实际账单核对。\n\n## 准备进一步咨询\n\n记录对应订单与问题截图，通过后台「消息 → 支持 → 创建案例」提交问题。', related: ['finance-2', 'faq-10', 'support-0'] },
  'returns-0': { title: '退货退款规则与参考入口', description: '找到平台退货退款说明，继续查看售后和财务相关指南。' },
  'marketing-0': { title: '广告活动与推广资料', description: '查找 Bestsellers 活动资料与 boost 相关说明。', resource: 'Bestsellers 活动教程' },
  'marketing-1': { title: '促销工具与活动教程索引', description: '活动报名与推广工具的详细操作教程继续整理。' },
  'brand-1': { title: '品牌文件审核与进一步支持', description: '审核结果查询与回复相关材料继续整理。' },
  'support-1': { title: '跟进工单与补充材料', description: '工单回复界面与后续跟进教程继续整理。' },
  'brand-0': { title: '准备与上传品牌授权文件', description: '找到文件入口，填写品牌、文件类型与有效期并上传证明。', complete: '品牌文件已上传并保存。', related: ['faq-7', 'support-0', 'brand-1'] },
  'support-0': { title: '向平台提交工单（开 case）', description: '找到后台支持入口，准备问题说明与截图。', markdown: section('support').split('**联系 示例服务商 客服**')[0], related: ['support-1', 'faq-10', 'faq-7'] },
};
const additions = [
  { id: 'start-5', chapter: 'start', title: '店铺激活与支付伙伴设置', source: '1.6', description: '注册之后，继续检查商品、FBS 仓库、库存和支付伙伴配置。',
    markdown: '## 激活前要完成什么\n\n1. 完成店铺注册并进入卖家后台。\n2. 至少上传一个产品，并设置 FBS 仓库。\n3. 为商品添加库存，继续完成支付伙伴和签约事项。\n\n## 选择支付伙伴\n\n' + partner,
    keywords: '激活 合同 签约 示例服务商 LIANLIAN 连连 FBS', related: ['shipping-3', 'finance-1', 'faq-1'] },
  { id: 'start-6', chapter: 'start', title: '禁售与限制商品查询', source: '1.4', description: '上架前分别查看平台禁售规则与物流渠道限制。', keywords: '禁售 违禁品 电池 食品 液体 限制', related: ['product-0', 'shipping-2'] },
  { id: 'finance-5', chapter: 'finance', title: '积分与费用抵扣说明', source: '2.5', description: '了解资料中积分的用途，并找到规则来源。', keywords: '积分 points 补偿 抵扣 优惠', related: ['finance-3', 'marketing-0'] },
  { id: 'finance-6', chapter: 'finance', title: '物流费用参考与试算入口', source: '2.6', description: '按跨境与本土模式，集中查找运费参考和工具。', keywords: '运费 物流费 最后一公里 MKAD 体积 升', related: ['shipping-0', 'shipping-4'], resource: '跨境运费定价表' },
  { id: 'shipping-4', chapter: 'shipping', title: '本土发货与 FBS Last Mile', source: '4.4', description: '货物已经在俄罗斯时，查看本土发货与收货点入口。', keywords: '本土 海外仓 俄罗斯 Last Mile 最后一公里', related: ['shipping-0', 'finance-6', 'faq-8'] },
  { id: 'shipping-5', chapter: 'shipping', title: '示例服务商 揽收点与操作中心', source: '5.3', description: '了解操作中心分布与详细揽收点资料的获取方式。', keywords: '揽收点 地址 仓址 东莞 义乌 深圳 平湖 黑河', related: ['shipping-2', 'support-0'] },
  { id: 'logistics-2', chapter: 'logistics', title: 'Extra Small 轻小件仓库设置', source: '5.2', description: '了解专仓设置顺序，以及商品转仓后的检查事项。',
    markdown: ('**Extra Small' + (section('5.2').split('**Extra Small')[1] || '')).replace(/① /g, '\n\n1. ').replace(/；② /g, '\n2. ').replace(/；③ /g, '\n3. '),
    keywords: 'Extra Small 超级轻小件 小包 专仓 500g 1500 转仓', related: ['shipping-3', 'logistics-0', 'faq-4'] },
];
const deferred = new Set(['finance-4', 'finance-6', 'product-1', 'marketing-1', 'brand-1', 'support-1', 'migration-0']);
const faqRelated = [['start-2', 'finance-1'], ['shipping-3', 'start-5'], ['product-0'], ['logistics-0', 'shipping-2'],
  ['logistics-2', 'logistics-0'], ['support-0'], ['support-0', 'logistics-1'], ['brand-0', 'support-0'],
  ['shipping-4', 'support-0'], ['migration-0'], ['finance-2', 'support-0']];
const faqTags = ['账户', '开店', '商品', '物流', '物流', '账户', '商品', '商品', '物流', '账户', '收款'];
const faqAliases = ['店铺id 编号 shop id business id 哪里看', '激活失败 开不了店 FBP FBS 无法激活',
  '价格自己变了 价格自动变了 价格变动 同步 取消同步', '无法运送 配送失败 运不到 不支持配送 地点报错',
  '被隐藏 轻小件 商品不显示', '关联 账号 多店铺', '质量指数 隐藏 封禁', '真实性 质疑 品牌 授权 发票',
  '海外仓 取件 取货 申请书', '迁移 卢布 人民币 通道', '没收到钱 钱没到 回款没到 回款不到账 没有回款 扣款'];
const faqs = sellerSource.faqs.map((item, index) => ({
  id: `faq-${index}`, chapter: 'faq', title: item.title, kind: 'question', tag: faqTags[index], source: `第九章 · 第${index+1}题`,
  status: index === 9 ? 'pending' : 'ready', description: index === 9 ? '迁移通道和适用条件相关内容继续整理。' : plainText(item.markdown.split('\n\n')[0]),
  markdown: index === 9 ? '' : clean(item.markdown), keywords: faqAliases[index], related: faqRelated[index],
}));

export const articles = [...legacyArticles.filter(item => item.chapter !== 'faq'), ...additions, ...faqs].map(base => {
  const item = { ...base, source: base.source || sources[base.id], ...metadata[base.id] };
  const status = item.status || (deferred.has(item.id) ? 'pending' : 'ready');
  const markdown = status === 'pending' ? '' : clean(item.markdown ?? section(item.source));
  const blocks = markdownBlocks(markdown, sellerSource.images);
  return { kind: 'guide', before: [], related: [], ...item, status, markdown, blocks,
    redirect: item.chapter === 'documents',
    chapterName: legacyChapters.find(chapter => chapter.id === item.chapter)?.name,
    outline: blocks.filter(block => block.type === 'heading').map(block => block.text),
    readMinutes: Math.max(1, Math.ceil(plainText(markdown).length / 450)), sourceTitle: sellerSource.title,
  };
});
export const chapters = legacyChapters.map(chapter => ({ ...chapter,
  name: chapter.id === 'logistics' ? '物流与仓库设置' : chapter.name,
  category: categories.find(category => category.chapters.includes(chapter.id))?.id,
  topics: articles.filter(item => item.chapter === chapter.id && !item.redirect).map(item => item.title),
}));
export const resources = [
  ...legacyResources.map(resource => ({ ...resource, group: resource.href ? 'tools' : 'files' })),
  { name: 'Yandex 官方中文教程', format: '官方', purpose: '查看平台中文帮助与操作说明', href: 'https://yandex.ru/support/global-marketplace/zh/introduction/', group: 'official' },
  { name: '平台跨境佣金表', format: '官方', purpose: '按跨境发货模式查找类目佣金', href: 'https://yandex.ru/legal/marketplace_crossborder_services_rate_table/ru/', group: 'official' },
  { name: '平台海外仓佣金表', format: '官方', purpose: '查看本土发货相关佣金参考', href: 'https://yandex.ru/legal/marketplace_crossborder_services_rate_table_fbslm/ru/', group: 'official' },
  { name: '示例服务商 类目佣金查询', format: '工具', purpose: '按类目关键词查询佣金参考', href: 'https://example.invalid/removed', group: 'tools' },
  { name: '包裹轨迹查询', format: '工具', purpose: '使用 17TRACK 查询包裹，运输商选择 示例服务商', href: 'https://www.17track.net', group: 'tools' },
  { name: '平台付款说明', format: '官方', purpose: '查找付款计划与付款频率说明', href: 'https://yandex.ru/support/global-marketplace/zh/accounting/payment?tabs=period_four-weeks', group: 'official' },
  { name: '平台禁售规则', format: '官方', purpose: '查找禁售商品与限制要求', href: 'https://yandex.ru/support/global-marketplace/zh/assortment/restrictions/', group: 'official' },
  { name: '平台退货退款说明', format: '官方', purpose: '查看买家退货退款规则', href: 'https://yandex.ru/support/global-marketplace/zh/orders/returns/buyer-s-rights', group: 'official' },
];
export const glossary = sellerSource.glossary.filter(item => !/服务费 1\.3%|提现手续费/.test(item.term));
export const questions = faqs.map(item => ({ title: item.title, context: item.description, article: item.id, tag: item.tag, status: item.status }));
export const knowledgeSearchIndex = buildSearchIndex(articles, resources, glossary);
export const findArticle = id => articles.find(item => item.id === id);
const readingOrder = {
  start: ['start-0', 'start-1', 'start-3', 'start-4', 'start-2', 'start-5', 'start-6'],
  finance: ['finance-1', 'finance-0', 'finance-2', 'finance-3', 'finance-5', 'finance-6', 'finance-4'],
  shipping: ['shipping-0', 'shipping-2', 'shipping-1', 'shipping-4', 'shipping-3', 'shipping-5'],
};
export const chapterArticles = id => {
  const list = articles.filter(item => item.chapter === id && !item.redirect);
  const order = readingOrder[id];
  return order ? list.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id)) : list;
};
