import { withBase } from './site-path.js';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowUpRight, CaretDown, List, MagnifyingGlass, X } from '@phosphor-icons/react';
import { navigation } from './navigation.js';
import { announcement } from './announcement.js';
import { AnnouncementBar } from './AnnouncementBar.jsx';
import './knowledge-header.css';

function FeaturedGuide({ guide, onNavigate }) {
  return <button className="knowledge-feature" type="button" onClick={() => onNavigate(guide.target)}>
    <img src={withBase('/assets/brand/merchant-guide-burgundy.png')} alt="酒红色商家指南与橙红色包裹" width="1448" height="1086" />
    <span className="knowledge-feature-body">
      <span className="knowledge-feature-label">{guide.label}</span>
      <strong>{guide.title}</strong>
      <span className="knowledge-feature-description">{guide.description}</span>
      <span className="knowledge-feature-link">{guide.target.type === 'resources' ? '查看资料' : '查看指南'}<ArrowUpRight size={20} weight="bold" /></span>
    </span>
  </button>;
}

function TaskGroups({ groups, onNavigate, prefix }) {
  return groups.map((group, index) => <section className="knowledge-group" key={group.title} aria-labelledby={`${prefix}-group-${index}`}>
    <h2 id={`${prefix}-group-${index}`}>{group.title}</h2>
    <ul>{group.items.map(item => <li key={item.title}><button type="button" onClick={() => onNavigate(item.target)}>
      <strong>{item.title}</strong><span>{item.description}</span>
    </button></li>)}</ul>
  </section>);
}

export function KnowledgeHeader({ onNavigate, onSearch, onExpandedChange }) {
  const [active, setActive] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileSection, setMobileSection] = useState('getting-started');
  const [announcementDismissed, setAnnouncementDismissed] = useState(false);
  const headerRef = useRef(null);
  const triggerRefs = useRef({});
  const mobileTriggerRef = useRef(null);
  const mobilePanelRef = useRef(null);
  const timerRef = useRef(null);
  const pinned = useRef(false);
  const expanded = Boolean(active || mobileOpen);
  const current = navigation.find(item => item.id === active);

  const cancelTimer = () => { clearTimeout(timerRef.current); };
  const close = (restoreFocus = false) => {
    cancelTimer();
    if (restoreFocus) (mobileOpen ? mobileTriggerRef.current : triggerRefs.current[active])?.focus();
    pinned.current = false;
    setActive(null);
    setMobileOpen(false);
  };
  const navigate = target => {
    // The native content dialog should return focus to a visible navigation trigger.
    (mobileOpen ? mobileTriggerRef.current : triggerRefs.current[active])?.focus({ preventScroll: true });
    close();
    onNavigate(target);
  };
  const search = () => { close(); onSearch(); };

  useLayoutEffect(() => { onExpandedChange(expanded); }, [expanded, onExpandedChange]);
  useLayoutEffect(() => {
    const header = headerRef.current;
    const root = header.closest('.studio-root');
    const measure = () => root.style.setProperty('--knowledge-header-height', `${header.getBoundingClientRect().height}px`);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(header);
    return () => { observer.disconnect(); root.style.removeProperty('--knowledge-header-height'); };
  }, []);
  useLayoutEffect(() => {
    if (mobileOpen && mobilePanelRef.current) mobilePanelRef.current.scrollTop = 0;
  }, [mobileOpen]);
  useEffect(() => {
    const breakpoint = window.matchMedia('(max-width: 1100px)');
    const reset = () => { clearTimeout(timerRef.current); setActive(null); setMobileOpen(false); pinned.current = false; };
    breakpoint.addEventListener('change', reset);
    return () => { breakpoint.removeEventListener('change', reset); clearTimeout(timerRef.current); };
  }, []);
  useEffect(() => {
    if (!expanded) return;
    const dismiss = event => {
      if (event.key === 'Escape') { event.preventDefault(); close(true); }
    };
    document.addEventListener('keydown', dismiss);
    return () => document.removeEventListener('keydown', dismiss);
  }, [active, mobileOpen]);

  const scheduleOpen = (event, id) => {
    if (event.pointerType !== 'mouse' || !window.matchMedia('(hover: hover)').matches) return;
    cancelTimer();
    timerRef.current = setTimeout(() => setActive(id), 180);
  };
  const scheduleClose = event => {
    cancelTimer();
    if (event.pointerType === 'mouse' && !pinned.current) {
      timerRef.current = setTimeout(() => { setActive(null); }, 280);
    }
  };
  const toggle = id => {
    cancelTimer();
    // A hover-open menu becomes pinned on the first click; a second click closes it.
    if (active === id && pinned.current) close();
    else { pinned.current = true; setActive(id); }
  };
  const keyDown = event => {
    if (!expanded) return;
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(true); }
    if (event.key !== 'Tab') return;
    const controls = [...headerRef.current.querySelectorAll('a[href], button:not([disabled]), summary')]
      .filter(element => element.getClientRects().length > 0 && !element.closest('[hidden]'));
    const first = controls[0];
    const last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  };

  return <>
    {expanded && <button className="knowledge-scrim" aria-label="关闭导航菜单" tabIndex={-1} onClick={() => close(true)} />}
    <header className={`knowledge-header${expanded ? ' is-expanded' : ''}`} ref={headerRef} onKeyDown={keyDown}
      onPointerEnter={cancelTimer} onPointerLeave={scheduleClose}>
      {announcement.enabled && !announcementDismissed && <AnnouncementBar announcement={announcement}
        onMore={() => navigate({ type: 'announcement', announcement })}
        onDismiss={() => {
          setAnnouncementDismissed(true);
          headerRef.current.querySelector('.knowledge-brand')?.focus({ preventScroll: true });
        }} />}
      <div className="knowledge-main"><div className="knowledge-container">
        <a className="knowledge-brand" href={withBase('/')} onClick={event => {
          if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
          event.preventDefault(); navigate({ type: 'home' });
        }} aria-label="Yandex Market商家服务知识库首页">
          <img className="knowledge-brand-logo" src={withBase('/assets/brand/logo-for-sellers.png')} width="3302" height="670" alt="Market for sellers" /><span>商家服务知识库</span>
        </a>
        <nav className="knowledge-desktop-nav" aria-label="主导航">{navigation.map(item => <button type="button" key={item.id}
          ref={element => { triggerRefs.current[item.id] = element; }}
          id={`knowledge-trigger-${item.id}`} aria-expanded={active === item.id} aria-controls={`knowledge-menu-${item.id}`}
          onPointerEnter={event => scheduleOpen(event, item.id)} onPointerLeave={cancelTimer} onClick={() => toggle(item.id)}
          onKeyDown={event => {
            if (event.key !== 'ArrowDown') return;
            event.preventDefault(); cancelTimer(); pinned.current = true; setActive(item.id);
            requestAnimationFrame(() => document.getElementById(`knowledge-menu-${item.id}`)?.querySelector('button')?.focus());
          }}>
          {item.label}<CaretDown size={14} weight="bold" />
        </button>)}</nav>
        <button className="knowledge-search-cta" type="button" onClick={search}>查找操作指南<ArrowUpRight size={19} weight="bold" /></button>
        <button className="knowledge-mobile-search" type="button" aria-label="搜索知识库" onClick={search}><MagnifyingGlass size={23} /></button>
        <button className="knowledge-mobile-trigger" ref={mobileTriggerRef} type="button" aria-label={mobileOpen ? '关闭分类导航' : '打开分类导航'}
          aria-expanded={mobileOpen} aria-controls="knowledge-mobile-panel" onClick={() => { cancelTimer(); setMobileOpen(!mobileOpen); }}>
          {mobileOpen ? <X size={25} /> : <List size={25} />}
        </button>
      </div></div>
      <div className="knowledge-desktop-panel" hidden={!current} onPointerEnter={cancelTimer}>
        {navigation.map(item => <div key={item.id} id={`knowledge-menu-${item.id}`} role="region" aria-labelledby={`knowledge-trigger-${item.id}`} hidden={active !== item.id}>
          <div className="knowledge-menu-grid knowledge-container"><TaskGroups groups={item.groups} onNavigate={navigate} prefix={item.id} /><FeaturedGuide guide={item.featured} onNavigate={navigate} /></div>
          <div className="knowledge-menu-footer"><div className="knowledge-container"><button type="button" onClick={() => navigate({ type: 'faq' })}>卖家常见问题解答<ArrowUpRight size={19} weight="bold" /></button><button type="button" onClick={() => navigate({ type: 'library' })}>浏览全部运营指南<ArrowUpRight size={19} weight="bold" /></button></div></div>
        </div>)}
      </div>
      <div className="knowledge-mobile-panel" ref={mobilePanelRef} id="knowledge-mobile-panel" hidden={!mobileOpen}>
        <nav aria-label="手机分类导航">{navigation.map(item => <section className="knowledge-mobile-section" key={item.id}>
          <h2><button type="button" id={`mobile-trigger-${item.id}`} aria-expanded={mobileSection === item.id} aria-controls={`mobile-section-${item.id}`}
            onClick={() => setMobileSection(mobileSection === item.id ? null : item.id)}>{item.label}<CaretDown size={19} /></button></h2>
          <div id={`mobile-section-${item.id}`} aria-labelledby={`mobile-trigger-${item.id}`} hidden={mobileSection !== item.id}>
            <TaskGroups groups={item.groups} onNavigate={navigate} prefix={`mobile-${item.id}`} />
            <FeaturedGuide guide={item.featured} onNavigate={navigate} />
          </div>
        </section>)}</nav>
        <button className="knowledge-mobile-faq" type="button" onClick={() => navigate({ type: 'faq' })}>卖家常见问题解答<ArrowUpRight size={19} /></button>
        <button className="knowledge-mobile-faq" type="button" onClick={() => navigate({ type: 'library' })}>浏览全部运营指南<ArrowUpRight size={19} /></button>
      </div>
    </header>
  </>;
}
