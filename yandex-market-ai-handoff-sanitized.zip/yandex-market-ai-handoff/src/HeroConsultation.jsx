import { useRef, useState } from 'react';
import { ArrowUpRight, MagnifyingGlass, Sparkle } from '@phosphor-icons/react';

// An entry preview only; typed questions never leave this page.
export function HeroConsultation({ onSearch }) {
  const [question, setQuestion] = useState('');
  const [notice, setNotice] = useState(false);
  const input = useRef(null);
  return <div className="hero-consultation" data-intro>
    <div className="hero-consultation-label"><span><Sparkle size={14} weight="duotone" aria-hidden="true" />AI 商家咨询</span><span>功能筹备中</span></div>
    <form className="hero-consultation-form" onSubmit={event => { event.preventDefault(); setNotice(true); }}>
      <input ref={input} aria-label="向 AI 助手提问" aria-describedby="hero-ai-disclosure" value={question} onChange={event => setQuestion(event.target.value)} maxLength={2000} placeholder="向 AI 助手提问，例如：如何申请开店？" autoComplete="off" />
      <button type="submit">开始咨询<ArrowUpRight size={18} aria-hidden="true" /></button>
    </form>
    {notice && <div className="hero-consultation-notice" role="status"><strong>AI 咨询功能筹备中</strong><span>真实模型服务正在准备，你的问题已保留在输入框中。现在可先查阅知识库指南。</span></div>}
    <div className="hero-consultation-popular"><span>你可能想问</span>{[
      ['如何申请开店？', '申请开店'], ['如何设置 FBS 仓库？', 'FBS 仓库'], ['回款流程是什么？', '回款流程'],
    ].map(([text, short]) => <button key={text} aria-label={text} type="button" onClick={() => { setQuestion(text); input.current?.focus(); }}><span className="hero-question-full">{text}</span><span className="hero-question-short">{short}</span><ArrowUpRight size={11} aria-hidden="true" /></button>)}</div>
    <div className="hero-consultation-tools"><button id="studio-search" type="button" onClick={() => onSearch()}><MagnifyingGlass size={16} aria-hidden="true" />搜索知识库<ArrowUpRight size={12} aria-hidden="true" /></button><span aria-hidden="true" className="hero-tools-divider" /><p id="hero-ai-disclosure">AI 尚未开放，请勿输入个人或账户敏感信息。</p></div>
  </div>;
}
