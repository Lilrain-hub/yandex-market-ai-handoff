import { withBase } from './site-path.js';
import React from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App.jsx";
import { StudioHome } from "./StudioHome.jsx";
import "./styles.css";
import "./studio.css";
import "./brand-theme.css";

const isClassic = new URLSearchParams(window.location.search).get('view') === 'classic';

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    {isClassic ? <><App /><a className="classic-preview-link" href={withBase('/')}>查看新版首页</a></> : <StudioHome />}
  </React.StrictMode>,
);
