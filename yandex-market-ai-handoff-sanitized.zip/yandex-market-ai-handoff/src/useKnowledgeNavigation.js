import { useCallback, useEffect, useState } from 'react';
import { targetPath } from './knowledge-utils.js';
import { siteBase, withBase, withoutBase } from './site-path.js';

export function parseLocation(location, base = siteBase) {
  const path = withoutBase(location.pathname, base).replace(/\/+$/, '') || '/';
  let match;
  if (path === '/') return { type: 'home', key: path };
  if ((match = path.match(/^\/(guides|topics)\/([^/]+)$/))) {
    let id;
    try { id = decodeURIComponent(match[2]); } catch { return { type: 'missing', key: path }; }
    if (match[1] === 'guides' && id === 'documents-0') return { type: 'library', key: path };
    if (match[1] === 'guides' && id === 'documents-1') return { type: 'resources', key: path };
    if (match[1] === 'topics' && id === 'documents') return { type: 'library', key: path };
    if (match[1] === 'topics' && id === 'faq') return { type: 'faq', key: path };
    return { type: match[1] === 'guides' ? 'article' : 'chapter', id, key: path };
  }
  const type = { '/library': 'library', '/questions': 'faq', '/resources': 'resources', '/glossary': 'glossary' }[path];
  return { type: type || 'missing', key: path + location.search,
    highlight: new URLSearchParams(location.search).get('highlight') };
}

export function useKnowledgeNavigation() {
  const [route, setRoute] = useState(() => parseLocation(window.location));
  useEffect(() => {
    const previous = history.scrollRestoration;
    history.scrollRestoration = 'manual';
    const pop = () => {
      setRoute(parseLocation(window.location));
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const anchor = document.getElementById(window.location.hash.slice(1));
        if (anchor) anchor.scrollIntoView();
        else window.scrollTo(0, history.state?.knowledgeScroll || 0);
      }));
    };
    window.addEventListener('popstate', pop);
    return () => { history.scrollRestoration = previous; window.removeEventListener('popstate', pop); };
  }, []);
  const navigate = useCallback(target => {
    const href = typeof target === 'string' ? withBase(target) : targetPath(target);
    if (href !== window.location.pathname + window.location.search) {
      history.replaceState({ ...history.state, knowledgeScroll: window.scrollY }, '', window.location.href);
      history.pushState({ knowledgeScroll: 0 }, '', href);
    }
    setRoute(parseLocation(window.location));
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);
  return { route, navigate };
}
