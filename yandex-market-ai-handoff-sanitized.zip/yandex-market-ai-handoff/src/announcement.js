// Replace this content and set href when the official announcement page is ready.
export const announcement = {
  enabled: true,
  label: 'NEW ARRIVAL',
  message: 'Yandex Market 超级店铺新入驻渠道即将发布，更多经营可能，10月23日见。',
  actionLabel: '了解更多',
  href: null,
};
