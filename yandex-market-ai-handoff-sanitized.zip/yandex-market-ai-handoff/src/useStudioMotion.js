import { useCallback, useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(useGSAP, ScrollTrigger);

export function useStudioMotion(rootRef, layoutKey) {
  const intro = useRef(null);
  const reveals = useRef(new Map());
  const pointer = useRef(null);
  const hasEntered = useRef(false);

  useGSAP(() => {
    const root = rootRef.current;
    if (!root) return;

    const media = gsap.matchMedia();
    const select = gsap.utils.selector(root);
    const art = select('.studio-hero-art')[0];

    media.add({
      reduced: '(prefers-reduced-motion: reduce)',
      animated: '(prefers-reduced-motion: no-preference)',
    }, ({ conditions }) => {
      if (conditions.reduced) {
        hasEntered.current = true;
        return;
      }

      const entries = select('[data-intro]').filter(element => element !== art);
      const sequence = gsap.timeline({
        defaults: { ease: 'power3.out' },
        onComplete: () => { hasEntered.current = true; },
      });

      if (entries.length) {
        sequence.fromTo(entries, { y: 22, opacity: 0 }, {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: { amount: 0.16 },
          clearProps: 'transform,opacity',
        }, 0);
      }
      if (art) {
        sequence.fromTo(art, { scale: 1.04 }, {
          scale: 1,
          duration: 0.8,
        }, 0);
      }
      intro.current = sequence;
      if (hasEntered.current) sequence.progress(1);

      // Content already reached on load stays visible, including restored scroll positions.
      select('[data-reveal]').forEach(element => {
        if (element.getBoundingClientRect().top < window.innerHeight) return;
        const tween = gsap.fromTo(element, { y: 18, opacity: 0 }, {
          y: 0,
          opacity: 1,
          duration: 0.55,
          ease: 'power2.out',
          clearProps: 'transform,opacity',
          scrollTrigger: {
            trigger: element,
            start: 'top 93%',
            once: true,
          },
        });
        reveals.current.set(element, tween);
      });

      const refreshReveals = () => {
        reveals.current.forEach(tween => tween.scrollTrigger?.refresh());
      };
      root.addEventListener('load', refreshReveals, true);
      root.ownerDocument.fonts?.addEventListener('loadingdone', refreshReveals);

      return () => {
        root.removeEventListener('load', refreshReveals, true);
        root.ownerDocument.fonts?.removeEventListener('loadingdone', refreshReveals);
        intro.current = null;
        reveals.current.clear();
      };
    }, root);

    media.add(
      '(min-width: 901px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)',
      () => {
        if (!art) return;
        pointer.current = {
          area: art.closest('.studio-hero') || art.parentElement || art,
          x: gsap.quickTo(art, 'x', { duration: 0.45, ease: 'power3.out' }),
          y: gsap.quickTo(art, 'y', { duration: 0.45, ease: 'power3.out' }),
        };
        return () => { pointer.current = null; };
      },
      root,
    );

    return () => media.revert();
  }, { scope: rootRef });

  const refresh = useCallback(() => {
    // Filtering chapters changes the position of the sections below the index.
    reveals.current.forEach(tween => {
      tween.scrollTrigger?.refresh();
      tween.scrollTrigger?.update();
    });
  }, []);

  useLayoutEffect(refresh, [layoutKey, refresh]);

  const finish = useCallback(event => {
    intro.current?.progress(1);
    const focused = event?.target || rootRef.current?.ownerDocument.activeElement;
    if (!focused) return;
    reveals.current.forEach((tween, element) => {
      if (!element.contains(focused)) return;
      tween.scrollTrigger?.kill(false, true);
      tween.progress(1);
    });
  }, [rootRef]);

  const onPointerMove = useCallback(event => {
    const follower = pointer.current;
    if (!follower || event.pointerType !== 'mouse') return;
    const box = follower.area.getBoundingClientRect();
    if (!box.width || !box.height) return;
    if (event.clientX < box.left || event.clientX > box.right
      || event.clientY < box.top || event.clientY > box.bottom) {
      follower.x(0);
      follower.y(0);
      return;
    }
    const clamp = value => Math.max(-6, Math.min(6, value));
    follower.x(clamp(((event.clientX - box.left) / box.width * 2 - 1) * 6));
    follower.y(clamp(((event.clientY - box.top) / box.height * 2 - 1) * 6));
  }, []);

  const onPointerLeave = useCallback(() => {
    pointer.current?.x(0);
    pointer.current?.y(0);
  }, []);

  return { finish, refresh, onPointerMove, onPointerLeave };
}
